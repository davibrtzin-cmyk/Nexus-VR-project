// Versões fixadas aqui. NÃO foram validadas contra o Maven neste ambiente (sem rede);
// se o Android Studio sugerir atualização compatível, aceite.
plugins {
    id("com.android.application") version "8.7.3" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.21" apply false
}
