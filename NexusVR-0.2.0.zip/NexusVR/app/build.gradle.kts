plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.nexusvr"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.nexusvr.app"
        minSdk = 26            // Realme C61 roda Android 14; 26 cobre ícones adaptativos e CameraX
        targetSdk = 35
        versionCode = 2
        versionName = "0.2.0-prototipo"
    }

    buildTypes {
        release {
            // Mantido desligado até haver testes em aparelho com as regras do MediaPipe validadas.
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    // O modelo do MediaPipe precisa ficar sem compressão no APK.
    androidResources {
        noCompress += "task"
    }
    testOptions {
        unitTests.isReturnDefaultValues = true
    }
}

// Baixa o modelo de mãos (Apache 2.0) para os assets, uma única vez, antes de compilar.
// Se não houver rede, só avisa: o app compila e funciona apenas com toque.
val fetchHandModel by tasks.registering {
    val target = layout.projectDirectory.file("src/main/assets/hand_landmarker.task").asFile
    val url = "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/latest/hand_landmarker.task"
    outputs.file(target)
    onlyIf { !target.exists() }
    doLast {
        target.parentFile.mkdirs()
        val tmp = File(target.parentFile, "hand_landmarker.task.part")
        try {
            java.net.URI(url).toURL().openStream().use { input -> tmp.outputStream().use { input.copyTo(it) } }
            tmp.renameTo(target)
        } catch (e: Exception) {
            tmp.delete()
            logger.warn("AVISO: não foi possível baixar o modelo de mãos (${e.message}). O app funcionará só com toque.")
        }
    }
}
tasks.named("preBuild") { dependsOn(fetchHandModel) }

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.9.3")

    val composeBom = platform("androidx.compose:compose-bom:2024.12.01")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")

    val camerax = "1.4.1"
    implementation("androidx.camera:camera-core:$camerax")
    implementation("androidx.camera:camera-camera2:$camerax")
    implementation("androidx.camera:camera-lifecycle:$camerax")
    implementation("androidx.camera:camera-view:$camerax")

    // Rastreamento de mãos on-device (Apache 2.0). O arquivo .task do modelo
    // é baixado por scripts/fetch_hand_model.sh e NÃO está versionado.
    implementation("com.google.mediapipe:tasks-vision:0.10.20")

    testImplementation("junit:junit:4.13.2")
}
