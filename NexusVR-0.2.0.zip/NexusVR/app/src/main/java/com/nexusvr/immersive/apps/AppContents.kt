package com.nexusvr.immersive.apps

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.SystemClock
import com.nexusvr.core.Box
import com.nexusvr.core.apps.AppCatalog
import com.nexusvr.core.apps.AppId
import com.nexusvr.immersive.SpatialStyle
import com.nexusvr.immersive.WindowContent
import com.nexusvr.immersive.drawWrapped
import com.nexusvr.immersive.ellipsize
import com.nexusvr.immersive.fill
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.min
import kotlin.math.roundToInt

/** Base de janelas com rolagem vertical. Desenha em coordenadas LOCAIS (0,0 = canto do corpo). */
abstract class ScrollableContent : WindowContent {
    private var scroll = 0f
    private var maxScroll = 0f
    protected val p = Paint(Paint.ANTI_ALIAS_FLAG)
    protected val r = RectF()

    /** Desenha o conteúdo e retorna a altura total usada. */
    protected abstract fun drawLocal(canvas: Canvas, w: Float, h: Float, st: SpatialStyle): Float

    /** Toque em coordenadas locais já somadas à rolagem. */
    protected abstract fun tapLocal(x: Float, y: Float)

    final override fun draw(canvas: Canvas, body: Box, style: SpatialStyle) {
        val save = canvas.save()
        canvas.translate(body.x, body.y - scroll)
        val total = drawLocal(canvas, body.w, body.h, style)
        canvas.restoreToCount(save)
        maxScroll = (total - body.h).coerceAtLeast(0f)
        if (scroll > maxScroll) scroll = maxScroll
    }

    final override fun onTap(localX: Float, localY: Float) = tapLocal(localX, localY + scroll)

    final override fun onScroll(dy: Float) {
        scroll = (scroll - dy).coerceIn(0f, maxScroll)
    }
}

internal fun drawBtn(c: Canvas, p: Paint, r: RectF, label: String, st: SpatialStyle, accent: Boolean = false) {
    c.drawRoundRect(r, st.dp(10f), st.dp(10f), p.fill(if (accent) st.accent2 else 0xFF1B2A44.toInt()))
    p.fill(st.text).textSize = st.sp(14f)
    p.typeface = Typeface.DEFAULT_BOLD
    p.textAlign = Paint.Align.CENTER
    c.drawText(label, r.centerX(), r.centerY() + st.dp(5f), p)
    p.textAlign = Paint.Align.LEFT
}

internal fun drawSwitch(c: Canvas, p: Paint, row: RectF, on: Boolean, st: SpatialStyle) {
    val tw = st.dp(48f)
    val th = st.dp(24f)
    val tr = RectF(row.right - tw - st.dp(12f), row.centerY() - th / 2f, row.right - st.dp(12f), row.centerY() + th / 2f)
    c.drawRoundRect(tr, th / 2f, th / 2f, p.fill(if (on) st.accent else 0xFF3A4A63.toInt()))
    val kx = if (on) tr.right - th / 2f else tr.left + th / 2f
    c.drawCircle(kx, tr.centerY(), th / 2f - st.dp(3f), p.fill(0xFFFFFFFF.toInt()))
}

// ------------------------------------------------------------------ Lançador

class LauncherContent(private val onLaunch: (AppId) -> Unit) : ScrollableContent() {
    private val tiles = ArrayList<Pair<RectF, AppId>>()

    override fun drawLocal(canvas: Canvas, w: Float, h: Float, st: SpatialStyle): Float {
        tiles.clear()
        val pad = st.dp(14f)
        val gap = st.dp(10f)
        p.typeface = Typeface.DEFAULT
        p.fill(st.textDim).textSize = st.sp(12f)
        var y = drawWrapped(
            canvas, "Toque para abrir. Navegador e Vídeo ainda estão em desenvolvimento.",
            pad, pad + st.sp(12f), w - pad * 2f, p, st.sp(16f),
        )
        y += st.dp(6f)
        val cols = ((w - pad * 2f + gap) / (st.dp(150f) + gap)).toInt().coerceAtLeast(1)
        val tw = (w - pad * 2f - gap * (cols - 1)) / cols
        val th = st.dp(76f)
        val apps = AppCatalog.launchable
        for ((i, app) in apps.withIndex()) {
            val x = pad + (i % cols) * (tw + gap)
            val ty = y + (i / cols) * (th + gap)
            val rect = RectF(x, ty, x + tw, ty + th)
            canvas.drawRoundRect(rect, st.dp(12f), st.dp(12f), p.fill(st.bgTitle))
            p.fill(st.text).textSize = st.sp(14f)
            p.typeface = Typeface.DEFAULT_BOLD
            canvas.drawText(ellipsize(p, app.label, tw - st.dp(20f)), x + st.dp(10f), ty + st.dp(30f), p)
            p.fill(st.textDim).textSize = st.sp(11f)
            p.typeface = Typeface.DEFAULT
            canvas.drawText(app.status.label, x + st.dp(10f), ty + st.dp(54f), p)
            tiles += rect to app
        }
        val rows = (apps.size + cols - 1) / cols
        return y + rows * (th + gap) + pad
    }

    override fun tapLocal(x: Float, y: Float) {
        tiles.firstOrNull { it.first.contains(x, y) }?.let { onLaunch(it.second) }
    }
}

// ------------------------------------------------------------------ Relógio e cronômetro

class ClockContent(private val sessionStart: Long) : ScrollableContent() {
    override val animated: Boolean = true

    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    private val dateFmt = SimpleDateFormat("EEEE, d 'de' MMMM", Locale.getDefault())
    private var running = false
    private var accum = 0L
    private var startedAt = 0L
    private val rStart = RectF()
    private val rReset = RectF()

    private fun swElapsed(): Long = accum + if (running) SystemClock.elapsedRealtime() - startedAt else 0L

    private fun mmss(ms: Long): String {
        val total = ms / 1000L
        val h = total / 3600L
        val m = (total % 3600L) / 60L
        val s = total % 60L
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s) else String.format(Locale.US, "%02d:%02d", m, s)
    }

    override fun drawLocal(canvas: Canvas, w: Float, h: Float, st: SpatialStyle): Float {
        val pad = st.dp(16f)
        val gap = st.dp(10f)
        val now = Date()
        p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.DEFAULT_BOLD
        p.fill(st.text).textSize = min(st.sp(44f), w * 0.2f)
        var y = pad + p.textSize
        canvas.drawText(timeFmt.format(now), w / 2f, y, p)
        p.typeface = Typeface.DEFAULT
        p.fill(st.textDim).textSize = st.sp(13f)
        y += st.dp(24f)
        canvas.drawText(dateFmt.format(now), w / 2f, y, p)
        y += st.dp(26f)
        canvas.drawText("Sessão  " + mmss(SystemClock.elapsedRealtime() - sessionStart), w / 2f, y, p)
        y += st.dp(34f)
        p.typeface = Typeface.DEFAULT_BOLD
        p.fill(st.accent).textSize = min(st.sp(30f), w * 0.14f)
        canvas.drawText(mmss(swElapsed()), w / 2f, y, p)
        p.textAlign = Paint.Align.LEFT
        y += st.dp(16f)
        val bw = (w - pad * 2f - gap) / 2f
        rStart.set(pad, y, pad + bw, y + st.dp(44f))
        rReset.set(pad + bw + gap, y, w - pad, y + st.dp(44f))
        drawBtn(canvas, p, rStart, if (running) "Pausar" else "Iniciar", st, accent = true)
        drawBtn(canvas, p, rReset, "Zerar", st)
        return y + st.dp(44f) + pad
    }

    override fun tapLocal(x: Float, y: Float) {
        val nowRt = SystemClock.elapsedRealtime()
        if (rStart.contains(x, y)) {
            if (running) { accum += nowRt - startedAt; running = false } else { startedAt = nowRt; running = true }
        } else if (rReset.contains(x, y)) {
            accum = 0L
            startedAt = nowRt
        }
    }
}

// ------------------------------------------------------------------ Ajuda

class HelpContent : ScrollableContent() {
    private val text = "MÃOS\n" +
        "Aproxime polegar e indicador (pinça) sobre um elemento para selecionar. " +
        "Mantenha a pinça e mova para arrastar uma janela pela barra de título ou redimensioná-la pela alça do canto. " +
        "Pinça no corpo da janela e movimento vertical rola listas.\n\n" +
        "Mantenha a mão a 30–60 cm da câmera traseira, com boa luz e a palma voltada para ela.\n\n" +
        "TOQUE\n" +
        "Fora do VR Box, toque e arraste na tela funciona do mesmo jeito.\n\n" +
        "CONTROLE BLUETOOTH\n" +
        "Analógico esquerdo ou direcional move o cursor. Botão A seleciona, B volta ao menu, Y abre os apps. " +
        "Pareie o controle antes, nos ajustes de Bluetooth do Android.\n\n" +
        "MODO VR BOX\n" +
        "Em Ferramentas, ligue Modo VR Box: a tela vira duas imagens lado a lado. O fundo passa a ser um ambiente virtual " +
        "e a câmera só reconhece suas mãos. A profundidade é um efeito de paralaxe; não há correção das lentes.\n\n" +
        "LIMITAÇÕES\n" +
        "O VR Box é só um suporte de celular: não há sensores de profundidade nem ancoragem no ambiente. " +
        "O rastreamento depende da luz e do desempenho do aparelho."

    override fun drawLocal(canvas: Canvas, w: Float, h: Float, st: SpatialStyle): Float {
        val pad = st.dp(16f)
        p.typeface = Typeface.DEFAULT
        p.fill(st.text).textSize = st.sp(14f)
        val end = drawWrapped(canvas, text, pad, pad + st.sp(14f), w - pad * 2f, p, st.sp(20f))
        return end + pad
    }

    override fun tapLocal(x: Float, y: Float) {}
}

// ------------------------------------------------------------------ Ferramentas

interface ToolsHost {
    var stereo: Boolean
    var skeleton: Boolean
    var diagnostics: Boolean
    var controllerEnabled: Boolean
    var depth: Float
    val environmentLabel: String
    fun nextEnvironment()
}

class ToolsContent(private val host: ToolsHost) : ScrollableContent() {
    private val hits = ArrayList<Pair<RectF, () -> Unit>>()

    override fun drawLocal(canvas: Canvas, w: Float, h: Float, st: SpatialStyle): Float {
        hits.clear()
        val pad = st.dp(14f)
        val rowH = st.dp(46f)
        val gap = st.dp(8f)
        var y = pad

        fun row(label: String, extra: (RectF) -> Unit, action: (() -> Unit)?) {
            r.set(pad, y, w - pad, y + rowH)
            canvas.drawRoundRect(r, st.dp(10f), st.dp(10f), p.fill(0xFF121E33.toInt()))
            p.fill(st.text).textSize = st.sp(14f)
            p.typeface = Typeface.DEFAULT
            p.textAlign = Paint.Align.LEFT
            canvas.drawText(label, r.left + st.dp(12f), r.centerY() + st.dp(5f), p)
            extra(r)
            if (action != null) hits += RectF(r) to action
            y += rowH + gap
        }

        row("Modo VR Box", { rr -> drawSwitch(canvas, p, rr, host.stereo, st) }) { host.stereo = !host.stereo }
        row("Esqueleto da mão", { rr -> drawSwitch(canvas, p, rr, host.skeleton, st) }) { host.skeleton = !host.skeleton }
        row("Diagnóstico", { rr -> drawSwitch(canvas, p, rr, host.diagnostics, st) }) { host.diagnostics = !host.diagnostics }
        row("Controle Bluetooth", { rr -> drawSwitch(canvas, p, rr, host.controllerEnabled, st) }) {
            host.controllerEnabled = !host.controllerEnabled
        }
        row("Ambiente: " + host.environmentLabel, { rr ->
            val b = RectF(rr.right - st.dp(86f), rr.top + st.dp(7f), rr.right - st.dp(10f), rr.bottom - st.dp(7f))
            drawBtn(canvas, p, b, "Trocar", st)
        }) { host.nextEnvironment() }
        row("Profundidade " + (host.depth * 100f).roundToInt() + "%", { rr ->
            val plus = RectF(rr.right - st.dp(46f), rr.top + st.dp(7f), rr.right - st.dp(10f), rr.bottom - st.dp(7f))
            val minus = RectF(plus.left - st.dp(42f), plus.top, plus.left - st.dp(6f), plus.bottom)
            drawBtn(canvas, p, minus, "−", st)
            drawBtn(canvas, p, plus, "+", st)
            hits += minus to { host.depth = (((host.depth * 10f).roundToInt() - 1) / 10f).coerceIn(0f, 1f) }
            hits += plus to { host.depth = (((host.depth * 10f).roundToInt() + 1) / 10f).coerceIn(0f, 1f) }
        }, null)

        p.fill(st.textDim).textSize = st.sp(11f)
        y = drawWrapped(
            canvas, "Ligar ou desligar o Modo VR Box reinicia a câmera por um instante.",
            pad, y + st.sp(10f), w - pad * 2f, p, st.sp(15f),
        )
        return y + pad
    }

    override fun tapLocal(x: Float, y: Float) {
        // os botões − e + foram registrados depois da linha, então têm prioridade (busca do fim para o início)
        hits.lastOrNull { it.first.contains(x, y) }?.second?.invoke()
    }
}

// ------------------------------------------------------------------ Galeria

class GalleryContent(private val onPick: () -> Unit) : ScrollableContent() {
    private var images: List<Bitmap> = emptyList()
    private var index = 0
    private var closed = false
    private val rPick = RectF()
    private val rPrev = RectF()
    private val rNext = RectF()
    private val dst = RectF()

    fun setImages(list: List<Bitmap>) {
        if (closed) { list.forEach { it.recycle() }; return }
        val old = images
        images = list
        index = 0
        old.forEach { it.recycle() }
    }

    override fun onClose() {
        closed = true
        images.forEach { it.recycle() }
        images = emptyList()
    }

    override fun drawLocal(canvas: Canvas, w: Float, h: Float, st: SpatialStyle): Float {
        val pad = st.dp(14f)
        val gap = st.dp(10f)
        var y = pad
        rPick.set(pad, y, w - pad, y + st.dp(44f))
        drawBtn(canvas, p, rPick, "Escolher fotos", st, accent = true)
        y += st.dp(44f) + gap
        rPrev.setEmpty(); rNext.setEmpty()
        val n = images.size
        if (n == 0) {
            p.typeface = Typeface.DEFAULT
            p.fill(st.textDim).textSize = st.sp(13f)
            drawWrapped(
                canvas, "Nenhuma foto escolhida. As imagens ficam só na memória e não são copiadas nem enviadas.",
                pad, y + st.sp(13f), w - pad * 2f, p, st.sp(18f),
            )
            return h
        }
        val navH = st.dp(44f)
        val areaBottom = (h - pad - navH - gap).coerceAtLeast(y + st.dp(40f))
        val b = images[index.coerceIn(0, n - 1)]
        val aw = w - pad * 2f
        val ah = areaBottom - y
        val scale = min(aw / b.width, ah / b.height)
        val bw = b.width * scale
        val bh = b.height * scale
        dst.set(w / 2f - bw / 2f, y + (ah - bh) / 2f, w / 2f + bw / 2f, y + (ah - bh) / 2f + bh)
        canvas.drawBitmap(b, null, dst, p.fill(0xFFFFFFFF.toInt()))
        val ny = areaBottom + gap
        rPrev.set(pad, ny, pad + st.dp(64f), ny + navH)
        rNext.set(w - pad - st.dp(64f), ny, w - pad, ny + navH)
        drawBtn(canvas, p, rPrev, "‹", st)
        drawBtn(canvas, p, rNext, "›", st)
        p.fill(st.text).textSize = st.sp(14f)
        p.typeface = Typeface.DEFAULT
        p.textAlign = Paint.Align.CENTER
        canvas.drawText("${index + 1} / $n", w / 2f, ny + navH / 2f + st.dp(5f), p)
        p.textAlign = Paint.Align.LEFT
        return h
    }

    override fun tapLocal(x: Float, y: Float) {
        val n = images.size
        when {
            rPick.contains(x, y) -> onPick()
            n > 1 && rPrev.contains(x, y) -> index = (index - 1 + n) % n
            n > 1 && rNext.contains(x, y) -> index = (index + 1) % n
        }
    }
}
