package com.nexusvr.core.window

import com.nexusvr.core.Box
import kotlin.math.min

/** Dimensões (em px) dos elementos de cromo das janelas. Vêm da densidade da tela. */
class WindowMetrics(
    val titleH: Float,
    val button: Float,
    val handle: Float,
    val dockH: Float,
    val dockItemW: Float,
    val margin: Float,
    val minW: Float,
    val minH: Float,
)

enum class WindowState { NORMAL, MINIMIZED }

/** Uma janela é só dados + tipo. O conteúdo é associado por quem desenha (ver SpatialView). */
class VirtualWindow(
    val id: Int,
    val typeId: String,
    var title: String,
    var box: Box,
    var state: WindowState = WindowState.NORMAL,
)

enum class Part { NONE, BODY, TITLE, CLOSE, MINIMIZE, RESIZE, DOCK }

data class Hit(val windowId: Int, val part: Part) {
    companion object {
        val NONE = Hit(-1, Part.NONE)
    }
}

/**
 * Gerencia janelas virtuais: ordem de empilhamento (lista = fundo→frente), foco, abrir/fechar,
 * minimizar/restaurar (dock), mover, redimensionar e hit-test. Lógica pura, testável na JVM.
 */
class WindowManager(val metrics: WindowMetrics) {
    private val list = ArrayList<VirtualWindow>()
    private var nextId = 1

    var boundsW = 0f
        private set
    var boundsH = 0f
        private set

    var onClosed: ((Int) -> Unit)? = null

    val windows: List<VirtualWindow> get() = list
    val focusedId: Int get() = list.lastOrNull { it.state == WindowState.NORMAL }?.id ?: -1

    fun get(id: Int): VirtualWindow? = list.firstOrNull { it.id == id }

    fun setBounds(w: Float, h: Float) {
        if (w <= 0f || h <= 0f) return
        if (boundsW > 0f && boundsH > 0f && (w != boundsW || h != boundsH)) {
            val sx = w / boundsW
            val sy = h / boundsH
            for (win in list) {
                val b = win.box
                win.box = clamp(Box(b.x * sx, b.y * sy, b.w * sx, b.h * sy), w, h)
            }
        }
        boundsW = w
        boundsH = h
    }

    fun open(typeId: String, title: String, box: Box): VirtualWindow {
        val win = VirtualWindow(nextId++, typeId, title, clamp(box))
        list.add(win)
        return win
    }

    fun close(id: Int): Boolean {
        val win = get(id) ?: return false
        list.remove(win)
        onClosed?.invoke(id)
        return true
    }

    fun focus(id: Int) {
        val win = get(id) ?: return
        if (win.state == WindowState.MINIMIZED) return
        if (list.last() !== win) {
            list.remove(win)
            list.add(win)
        }
    }

    fun minimize(id: Int) {
        get(id)?.state = WindowState.MINIMIZED
    }

    fun restore(id: Int) {
        val win = get(id) ?: return
        win.state = WindowState.NORMAL
        focus(id)
    }

    /** Posiciona a janela com o canto superior esquerdo em (x, y), limitado à área visível. */
    fun moveTo(id: Int, x: Float, y: Float) {
        val win = get(id) ?: return
        win.box = clamp(win.box.copy(x = x, y = y))
    }

    /** Define o tamanho, respeitando mínimo e a borda da área (a janela não é empurrada). */
    fun resizeTo(id: Int, w: Float, h: Float) {
        val win = get(id) ?: return
        if (boundsW <= 0f || boundsH <= 0f) return
        val maxW = boundsW - win.box.x
        val maxH = boundsH - win.box.y
        val nw = w.coerceIn(min(metrics.minW, maxW), maxW)
        val nh = h.coerceIn(min(metrics.minH, maxH), maxH)
        win.box = win.box.copy(w = nw, h = nh)
    }

    // --- geometria do cromo (usada tanto para desenhar quanto para hit-test) ---

    fun titleBox(w: VirtualWindow) = Box(w.box.x, w.box.y, w.box.w, metrics.titleH)

    fun bodyBox(w: VirtualWindow) =
        Box(w.box.x, w.box.y + metrics.titleH, w.box.w, w.box.h - metrics.titleH)

    private fun pad() = (metrics.titleH - metrics.button) / 2f

    fun closeBox(w: VirtualWindow) =
        Box(w.box.right - pad() - metrics.button, w.box.y + pad(), metrics.button, metrics.button)

    fun minimizeBox(w: VirtualWindow) =
        Box(closeBox(w).x - pad() - metrics.button, w.box.y + pad(), metrics.button, metrics.button)

    fun resizeBox(w: VirtualWindow) =
        Box(w.box.right - metrics.handle, w.box.bottom - metrics.handle, metrics.handle, metrics.handle)

    fun dockBox(index: Int) = Box(
        metrics.margin + index * (metrics.dockItemW + metrics.margin),
        boundsH - metrics.dockH - metrics.margin,
        metrics.dockItemW,
        metrics.dockH,
    )

    fun minimizedWindows(): List<VirtualWindow> = list.filter { it.state == WindowState.MINIMIZED }

    fun hitTest(px: Float, py: Float): Hit {
        var i = 0
        for (w in list) {
            if (w.state != WindowState.MINIMIZED) continue
            if (dockBox(i).contains(px, py)) return Hit(w.id, Part.DOCK)
            i++
        }
        for (idx in list.indices.reversed()) {
            val w = list[idx]
            if (w.state != WindowState.NORMAL || !w.box.contains(px, py)) continue
            return Hit(w.id, partAt(w, px, py))
        }
        return Hit.NONE
    }

    private fun partAt(w: VirtualWindow, px: Float, py: Float): Part = when {
        closeBox(w).contains(px, py) -> Part.CLOSE
        minimizeBox(w).contains(px, py) -> Part.MINIMIZE
        py < w.box.y + metrics.titleH -> Part.TITLE
        resizeBox(w).contains(px, py) -> Part.RESIZE
        else -> Part.BODY
    }

    private fun clamp(b: Box, bw: Float = boundsW, bh: Float = boundsH): Box {
        if (bw <= 0f || bh <= 0f) return b // limites ainda desconhecidos (antes do layout)
        val w = b.w.coerceIn(min(metrics.minW, bw), bw)
        val h = b.h.coerceIn(min(metrics.minH, bh), bh)
        return Box(b.x.coerceIn(0f, bw - w), b.y.coerceIn(0f, bh - h), w, h)
    }
}
