package com.nexusvr.immersive

import android.Manifest
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.util.Size
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.ImageAnalysis
import androidx.camera.view.PreviewView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import com.nexusvr.core.Box
import com.nexusvr.core.FillCenterMapper
import com.nexusvr.core.gesture.GestureConfig
import com.nexusvr.core.gesture.GestureEngine
import com.nexusvr.core.input.InputSource
import com.nexusvr.core.input.PointerExit
import com.nexusvr.core.settings.NexusSettings
import com.nexusvr.core.settings.OrientationPref
import com.nexusvr.platform.DeviceInfo
import com.nexusvr.platform.DeviceInfoProvider
import com.nexusvr.platform.SettingsRepository
import java.util.Locale
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.os.Build
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import androidx.activity.result.PickVisualMediaRequest
import com.nexusvr.core.apps.AppId
import com.nexusvr.core.experience.ExperienceManifest
import com.nexusvr.core.experience.LocalExperienceRegistry
import com.nexusvr.core.input.ControllerCursor
import com.nexusvr.core.settings.ViewMode
import com.nexusvr.core.window.WindowState
import com.nexusvr.immersive.apps.ClockContent
import com.nexusvr.immersive.apps.GalleryContent
import com.nexusvr.immersive.apps.HelpContent
import com.nexusvr.immersive.apps.LauncherContent
import com.nexusvr.immersive.apps.ToolsContent
import com.nexusvr.immersive.apps.ToolsHost
import java.util.concurrent.Executors

/**
 * Experiência imersiva. Fluxo (seção 4 do briefing):
 *   verificar câmera/permissão/gráficos/modelo → explicar e pedir permissão SOMENTE se necessária →
 *   iniciar câmera e rastreamento → carregar a camada espacial → entregar a interação.
 * Câmera e visão computacional só existem entre onStart e onStop.
 */
class ImmersiveActivity : ComponentActivity(), HandTracker.Listener {

    private lateinit var settings: NexusSettings
    private lateinit var info: DeviceInfo
    private lateinit var root: FrameLayout
    private lateinit var previewView: PreviewView
    private lateinit var spatial: SpatialView
    private lateinit var hud: TextView
    private lateinit var diag: TextView
    private var gate: View? = null

    private val main = Handler(Looper.getMainLooper())
    private val perf = PerfStats()
    private val engine = GestureEngine(GestureConfig())

    private lateinit var repo: SettingsRepository
    private lateinit var userSettings: NexusSettings   // o que o usuário salvou (sem os ajustes da experiência)
    private var experience: ExperienceManifest? = null
    private var galleryContent: GalleryContent? = null
    private val sessionStart = SystemClock.elapsedRealtime()
    private val io = Executors.newSingleThreadExecutor()

    // ---- controle Bluetooth / gamepad ----
    private val controller = ControllerCursor()
    private var controllerTicking = false
    private var lastControllerAt = 0L
    private var keyL = false
    private var keyR = false
    private var keyU = false
    private var keyD = false
    private var hatX = 0
    private var hatY = 0

    private val controllerLoop = object : Runnable {
        override fun run() {
            val now = SystemClock.uptimeMillis()
            val dt = now - lastControllerAt
            lastControllerAt = now
            spatial.dispatch(controller.update(dt))
            if (controller.isActive) main.postDelayed(this, 16L) else controllerTicking = false
        }
    }

    private val pickImages =
        registerForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(8)) { uris ->
            if (uris.isNotEmpty()) loadImages(uris)
        }

    private val toolsHost = object : ToolsHost {
        override var stereo: Boolean
            get() = settings.viewMode == ViewMode.STEREO
            set(v) = setStereoMode(v)
        override var skeleton: Boolean
            get() = settings.showHandSkeleton
            set(v) {
                changeSettings { it.copy(showHandSkeleton = v) }
                spatial.showSkeleton = v
                if (!v) spatial.setSkeleton(null)
            }
        override var diagnostics: Boolean
            get() = settings.showDiagnostics
            set(v) {
                changeSettings { it.copy(showDiagnostics = v) }
                applyDiagnostics()
            }
        override var controllerEnabled: Boolean
            get() = settings.controllerEnabled
            set(v) {
                changeSettings { it.copy(controllerEnabled = v) }
                if (!v) releaseController()
            }
        override var depth: Float
            get() = settings.stereoDepth
            set(v) {
                changeSettings { it.copy(stereoDepth = v) }
                spatial.configureStereo(settings.viewMode == ViewMode.STEREO, v)
                updateMapper()
            }
        override val environmentLabel: String get() = settings.environment.label
        override fun nextEnvironment() {
            changeSettings { it.copy(environment = it.environment.next()) }
            spatial.environment = settings.environment
        }
    }

    companion object {
        const val EXTRA_EXPERIENCE_ID = "experience_id"
        private const val LAUNCHER = "launcher"
    }

    private var camera: CameraController? = null
    private var tracker: HandTracker? = null

    private var entered = false
    private var cameraAllowed = false
    private var sceneStarted = false
    private var imageW = 0
    private var imageH = 0
    private var lastResultAt = 0L
    private val skeletonBuf = FloatArray(42)

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) enter(true) else showCameraDenied()
        }

    private val hideHud = Runnable { hud.visibility = View.GONE }

    private val watchdog = object : Runnable {
        override fun run() {
            val now = SystemClock.uptimeMillis()
            // Se o rastreador parou de entregar quadros, o motor ainda precisa perceber a ausência da mão.
            if (tracker != null && now - lastResultAt > 120L) processHand(null, now)
            main.postDelayed(this, 100L)
        }
    }

    private val diagUpdater = object : Runnable {
        override fun run() {
            val ratio = engine.lastPinchRatio
            diag.text = String.format(
                Locale.US, "mãos %.0f fps · %.0f ms · pinça %s",
                perf.fps, perf.latencyMs, if (ratio.isNaN()) "–" else String.format(Locale.US, "%.2f", ratio),
            )
            main.postDelayed(this, 500L)
        }
    }

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayChanged(displayId: Int) {
            camera?.setTargetRotation(displayRotation())
        }
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
    }

    // ------------------------------------------------------------------ ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repo = SettingsRepository(this)
        userSettings = repo.load()
        experience = intent.getStringExtra(EXTRA_EXPERIENCE_ID)?.let { LocalExperienceRegistry.find(it) }
        settings = experience?.let { e ->
            userSettings.copy(viewMode = e.viewMode ?: userSettings.viewMode, environment = e.environment ?: userSettings.environment)
        } ?: userSettings
        requestedOrientation = when (settings.orientation) {
            OrientationPref.SENSOR_LANDSCAPE -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            OrientationPref.LANDSCAPE -> ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            OrientationPref.REVERSE_LANDSCAPE -> ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        engine.config.sensitivity = settings.gestureSensitivity
        buildViews()
        hideSystemBars()
        begin()
    }

    override fun onStart() {
        super.onStart()
        if (entered) startScene()
    }

    override fun onStop() {
        stopScene()
        super.onStop()
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        io.shutdown()
        super.onDestroy()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    // ------------------------------------------------------------------ construção da interface

    private fun dp(v: Float) = (v * resources.displayMetrics.density).toInt()

    private fun buildViews() {
        root = FrameLayout(this).apply { setBackgroundColor(0xFF070B14.toInt()) }

        previewView = PreviewView(this).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
            visibility = View.GONE
        }
        spatial = SpatialView(this).apply {
            quality = settings.graphicsQuality
            showSkeleton = settings.showHandSkeleton
            environment = settings.environment
            useEnvironment = !settings.showCameraPreview
            configureStereo(settings.viewMode == ViewMode.STEREO, settings.stereoDepth)
            visibility = View.INVISIBLE   // só aparece depois do fluxo de entrada
            onMenuRequested = { finish() }
            onAppsRequested = { openLauncher() }
            onFirstLayout = { _, _ -> openInitialWindows() }
            addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> updateMapper() }
        }
        hud = TextView(this).apply {
            setTextColor(0xFFE6F1FF.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setPadding(dp(16f), dp(8f), dp(16f), dp(8f))
            background = GradientDrawable().apply { cornerRadius = dp(18f).toFloat(); setColor(0xCC070B14.toInt()) }
            visibility = View.GONE
        }
        diag = TextView(this).apply {
            setTextColor(0xFF8FA3BF.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            visibility = View.GONE
        }

        val match = ViewGroup.LayoutParams.MATCH_PARENT
        root.addView(previewView, FrameLayout.LayoutParams(match, match))
        root.addView(spatial, FrameLayout.LayoutParams(match, match))
        root.addView(
            hud,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
                .apply { topMargin = dp(16f) },
        )
        root.addView(
            diag,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.END)
                .apply { setMargins(0, 0, dp(14f), dp(10f)) },
        )
        setContentView(root)
    }

    private fun openInitialWindows() {
        val apps = experience?.initialApps ?: listOf(AppId.DEMO)
        for ((i, app) in apps.withIndex()) openApp(app, i)
    }

    /** Abre a janela do app; se já existe, restaura (se minimizada) e traz para a frente. */
    private fun openApp(app: AppId, slot: Int = spatial.windows.windows.size) {
        val existing = spatial.findWindow(app.name)
        if (existing != null) {
            if (existing.state == WindowState.MINIMIZED) spatial.windows.restore(existing.id) else spatial.windows.focus(existing.id)
            spatial.invalidate()
            return
        }
        val content = when (app) {
            AppId.DEMO -> DemoPanelContent()
            AppId.CLOCK -> ClockContent(sessionStart)
            AppId.HELP -> HelpContent()
            AppId.TOOLS -> ToolsContent(toolsHost)
            AppId.GALLERY -> GalleryContent {
                pickImages.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            }.also { galleryContent = it }
            else -> return   // navegador e vídeo ainda não existem
        }
        val (fw, fh) = when (app) {
            AppId.CLOCK -> 0.40f to 0.58f
            AppId.HELP -> 0.52f to 0.74f
            AppId.TOOLS -> 0.50f to 0.78f
            AppId.GALLERY -> 0.58f to 0.76f
            else -> 0.46f to 0.66f
        }
        placeWindow(app.name, app.label, content, fw, fh, slot)
    }

    private fun openLauncher() {
        val existing = spatial.findWindow(LAUNCHER)
        if (existing != null) {
            if (existing.state == WindowState.MINIMIZED) spatial.windows.restore(existing.id) else spatial.windows.focus(existing.id)
            spatial.invalidate()
            return
        }
        placeWindow(LAUNCHER, "Aplicativos", LauncherContent { openApp(it) }, 0.56f, 0.7f, spatial.windows.windows.size)
    }

    private fun placeWindow(typeId: String, title: String, content: WindowContent, fw: Float, fh: Float, slot: Int) {
        val w = spatial.logicalWidth
        val h = spatial.height.toFloat()
        val bw = w * fw
        val bh = h * fh
        val off = (slot % 4) * 26f * resources.displayMetrics.density
        spatial.openWindow(typeId, title, Box((w - bw) / 2f + off, (h - bh) / 2f + off, bw, bh), content)
    }

    private fun changeSettings(f: (NexusSettings) -> NexusSettings) {
        userSettings = f(userSettings)
        settings = f(settings)
        repo.save(userSettings)
    }

    private fun setStereoMode(on: Boolean) {
        if ((settings.viewMode == ViewMode.STEREO) == on) return
        changeSettings { it.copy(viewMode = if (on) ViewMode.STEREO else ViewMode.NORMAL) }
        spatial.configureStereo(on, settings.stereoDepth)
        spatial.useEnvironment = !(settings.showCameraPreview && cameraAllowed)
        updateMapper()
        // a câmera precisa ser reaberta com ou sem imagem de fundo; adiado para fora do callback de toque
        main.post {
            if (entered && lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) {
                stopScene()
                startScene()
            }
        }
    }

    private fun applyDiagnostics() {
        main.removeCallbacks(diagUpdater)
        if (settings.showDiagnostics) {
            diag.visibility = View.VISIBLE
            main.post(diagUpdater)
        } else {
            diag.visibility = View.GONE
        }
    }

    // ---- galeria: seletor de fotos do Android (sem permissão de armazenamento) ----

    private fun loadImages(uris: List<Uri>) {
        io.execute {
            val list = ArrayList<Bitmap>()
            for (u in uris.take(8)) decodeBitmap(u, 1024)?.let { list += it }
            main.post {
                val g = galleryContent
                if (g == null || list.isEmpty()) {
                    list.forEach { it.recycle() }
                    if (list.isEmpty()) showHud("Não foi possível abrir as imagens.", 4000L)
                } else {
                    g.setImages(list)
                    spatial.invalidate()
                }
            }
        }
    }

    private fun decodeBitmap(uri: Uri, maxDim: Int): Bitmap? = try {
        if (Build.VERSION.SDK_INT >= 28) {
            ImageDecoder.decodeBitmap(ImageDecoder.createSource(contentResolver, uri)) { decoder, info, _ ->
                val sw = info.size.width
                val sh = info.size.height
                val m = maxOf(sw, sh)
                if (m > maxDim) decoder.setTargetSize(sw * maxDim / m, sh * maxDim / m)
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            }
        } else {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > maxDim * 2) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        }
    } catch (e: Throwable) {
        null
    }

    // ---- controle Bluetooth / gamepad ----

    private fun controllerReady() = settings.controllerEnabled && entered && gate == null && sceneStarted

    private fun kickController() {
        if (!controllerTicking && controller.isActive) {
            controllerTicking = true
            lastControllerAt = SystemClock.uptimeMillis()
            main.post(controllerLoop)
        }
    }

    private fun pushDpad() {
        val x = ((if (keyR) 1 else 0) - (if (keyL) 1 else 0) + hatX).coerceIn(-1, 1)
        val y = ((if (keyD) 1 else 0) - (if (keyU) 1 else 0) + hatY).coerceIn(-1, 1)
        controller.setDpad(x, y)
        kickController()
    }

    private fun releaseController() {
        keyL = false; keyR = false; keyU = false; keyD = false; hatX = 0; hatY = 0
        main.removeCallbacks(controllerLoop)
        controllerTicking = false
        spatial.dispatch(controller.release())
    }

    override fun dispatchKeyEvent(ev: KeyEvent): Boolean {
        if (!controllerReady()) return super.dispatchKeyEvent(ev)
        val down = ev.action == KeyEvent.ACTION_DOWN
        val up = ev.action == KeyEvent.ACTION_UP
        if (!down && !up) return super.dispatchKeyEvent(ev)
        when (ev.keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT -> { keyL = down; pushDpad() }
            KeyEvent.KEYCODE_DPAD_RIGHT -> { keyR = down; pushDpad() }
            KeyEvent.KEYCODE_DPAD_UP -> { keyU = down; pushDpad() }
            KeyEvent.KEYCODE_DPAD_DOWN -> { keyD = down; pushDpad() }
            KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER ->
                spatial.dispatch(controller.onButton(down))
            KeyEvent.KEYCODE_BUTTON_B -> if (up) finish()
            KeyEvent.KEYCODE_BUTTON_Y -> if (up) openLauncher()
            else -> return super.dispatchKeyEvent(ev)
        }
        return true
    }

    override fun onGenericMotionEvent(ev: MotionEvent): Boolean {
        val joystick = (ev.source and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
        if (!controllerReady() || !joystick || ev.action != MotionEvent.ACTION_MOVE) return super.onGenericMotionEvent(ev)
        controller.setAxes(ev.getAxisValue(MotionEvent.AXIS_X), ev.getAxisValue(MotionEvent.AXIS_Y))
        hatX = Math.round(ev.getAxisValue(MotionEvent.AXIS_HAT_X))
        hatY = Math.round(ev.getAxisValue(MotionEvent.AXIS_HAT_Y))
        pushDpad()
        return true
    }

    private fun hideSystemBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.hide(WindowInsetsCompat.Type.systemBars())
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    private fun showHud(message: String, durationMs: Long) {
        hud.text = message
        hud.visibility = View.VISIBLE
        main.removeCallbacks(hideHud)
        main.postDelayed(hideHud, durationMs)
    }

    // ------------------------------------------------------------------ fluxo de entrada

    private fun begin() {
        info = DeviceInfoProvider.read(this)
        val pre = PreflightChecker.run(info, settings)
        val checklist = pre.items.joinToString("\n") { "${it.status.symbol}  ${it.label}: ${it.detail}" }

        when {
            !settings.cameraNeeded -> enter(false)

            !info.hasBackCamera -> showGate(
                "Câmera indisponível",
                "Não foi possível usar a câmera neste aparelho.\n\n$checklist\n\n" +
                    "Você pode continuar sem câmera (fundo escuro e controle por toque).",
                listOf(
                    "Continuar sem câmera" to { enter(false) },
                    "Voltar ao menu" to { finish() },
                ),
            )

            !info.cameraPermissionGranted -> showGate(
                "Permissão da câmera",
                "A experiência usa a câmera traseira para mostrar o ambiente e para reconhecer suas mãos. " +
                    "As imagens são processadas apenas neste aparelho, não são gravadas e não são enviadas a nenhum servidor.\n\n" +
                    checklist,
                listOf(
                    "Permitir câmera" to { permissionLauncher.launch(Manifest.permission.CAMERA) },
                    "Continuar sem câmera" to { enter(false) },
                    "Voltar ao menu" to { finish() },
                ),
            )

            else -> enter(true)
        }
    }

    private fun showCameraDenied() {
        showGate(
            "Câmera não autorizada",
            "Sem a permissão, não é possível mostrar o ambiente nem rastrear as mãos. " +
                "Você pode tentar novamente, liberar a câmera nas configurações do aplicativo ou continuar apenas com toque.",
            listOf(
                "Tentar novamente" to { permissionLauncher.launch(Manifest.permission.CAMERA) },
                "Abrir configurações do app" to {
                    startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null)),
                    )
                },
                "Continuar sem câmera" to { enter(false) },
                "Voltar ao menu" to { finish() },
            ),
        )
    }

    private fun enter(withCamera: Boolean) {
        hideGate()
        entered = true
        cameraAllowed = withCamera
        spatial.useEnvironment = !(settings.showCameraPreview && withCamera)
        spatial.visibility = View.VISIBLE
        if (lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) startScene()
    }

    private fun showGate(title: String, message: String, actions: List<Pair<String, () -> Unit>>) {
        hideGate()
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(32f), dp(24f), dp(32f), dp(24f))
        }
        column.addView(TextView(this).apply {
            text = title
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        column.addView(TextView(this).apply {
            text = message
            setTextColor(0xFF8FA3BF.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setPadding(0, dp(12f), 0, dp(16f))
        })
        actions.forEachIndexed { i, (label, action) ->
            column.addView(
                Button(this).apply {
                    text = label
                    isAllCaps = false
                    setTextColor(if (i == 0) 0xFF07101C.toInt() else Color.WHITE)
                    background = GradientDrawable().apply {
                        cornerRadius = dp(14f).toFloat()
                        setColor(if (i == 0) 0xFF3DE8FF.toInt() else 0xFF1B2A44.toInt())
                    }
                    setOnClickListener { action() }
                },
                LinearLayout.LayoutParams(dp(320f), dp(48f)).apply { topMargin = dp(8f) },
            )
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            isClickable = true
            setBackgroundColor(0xFF070B14.toInt())
            addView(column)
        }
        root.addView(scroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        gate = scroll
    }

    private fun hideGate() {
        gate?.let { root.removeView(it) }
        gate = null
    }

    // ------------------------------------------------------------------ cena (câmera + rastreamento)

    private fun startScene() {
        if (sceneStarted) return
        sceneStarted = true
        hideSystemBars()
        engine.reset()

        applyDiagnostics()

        if (!cameraAllowed || !settings.cameraNeeded) {
            if (settings.cameraNeeded) showHud("Sem câmera: use o toque na tela.", 6000L)
            return
        }

        var analyzer: ImageAnalysis.Analyzer? = null
        if (settings.handTrackingEnabled) {
            if (!info.handModelPresent) {
                showHud("Modelo de mãos ausente: use o toque na tela.", 8000L)
            } else {
                try {
                    val t = HandTracker(this, perf, this)
                    tracker = t
                    analyzer = HandFrameAnalyzer(t, settings.analysisFps) { w, h -> main.post { onGeometry(w, h) } }
                } catch (e: Throwable) {
                    tracker = null
                    showHud("Rastreamento de mãos indisponível: ${e.message ?: "erro desconhecido"}", 8000L)
                }
            }
        }

        val usePreview = settings.showCameraPreview
        previewView.visibility = if (usePreview) View.VISIBLE else View.GONE
        val res = settings.analysisResolution
        camera = CameraController(this).also {
            it.start(
                owner = this,
                previewView = if (usePreview) previewView else null,
                analyzer = analyzer,
                analysisSize = Size(res.w, res.h),
                rotation = displayRotation(),
                onError = { msg -> main.post { showHud("Câmera: $msg", 8000L) } },
            )
        }

        (getSystemService(DISPLAY_SERVICE) as DisplayManager).registerDisplayListener(displayListener, main)
        if (tracker != null) {
            lastResultAt = SystemClock.uptimeMillis()
            main.postDelayed(watchdog, 100L)
        }
    }

    private fun stopScene() {
        if (!sceneStarted) return
        sceneStarted = false
        main.removeCallbacks(watchdog)
        main.removeCallbacks(diagUpdater)
        try {
            (getSystemService(DISPLAY_SERVICE) as DisplayManager).unregisterDisplayListener(displayListener)
        } catch (_: Throwable) {
        }
        // Ordem: primeiro a câmera (para de entregar quadros), depois o rastreador.
        camera?.stop()
        camera = null
        tracker?.close()
        tracker = null
        imageW = 0
        imageH = 0
        engine.reset()
        spatial.interactor.onEvent(PointerExit(0f, 0f, InputSource.HAND))
        releaseController()
        spatial.setSkeleton(null)
    }

    @Suppress("DEPRECATION")
    private fun displayRotation(): Int = windowManager.defaultDisplay.rotation

    // ------------------------------------------------------------------ rastreamento → gestos → interface

    private fun onGeometry(w: Int, h: Int) {
        imageW = w
        imageH = h
        updateMapper()
    }

    private fun updateMapper() {
        controller.setBounds(spatial.logicalWidth, spatial.height.toFloat())
        if (imageW <= 0 || imageH <= 0 || spatial.logicalWidth <= 0f || spatial.height <= 0) return
        val m = FillCenterMapper(imageW, imageH, spatial.logicalWidth, spatial.height.toFloat())
        engine.mapper = { nx, ny -> m.map(nx, ny) }
        engine.config.imageAspect = imageW.toFloat() / imageH.toFloat()
    }

    override fun onHand(landmarks: FloatArray?, timestampMs: Long) {
        val now = SystemClock.uptimeMillis()
        lastResultAt = now
        processHand(landmarks, now)
    }

    override fun onError(message: String) {
        showHud("Rastreamento: $message", 6000L)
    }

    private fun processHand(landmarks: FloatArray?, now: Long) {
        if (imageW == 0) return
        spatial.dispatch(engine.onFrame(landmarks, now))
        if (settings.showHandSkeleton) updateSkeleton(landmarks)
    }

    private fun updateSkeleton(lm: FloatArray?) {
        if (lm == null) {
            spatial.setSkeleton(null)
            return
        }
        val map = engine.mapper
        for (i in 0 until 21) {
            val v = map(lm[i * 3], lm[i * 3 + 1])
            skeletonBuf[i * 2] = v.x
            skeletonBuf[i * 2 + 1] = v.y
        }
        spatial.setSkeleton(skeletonBuf)
    }
}
