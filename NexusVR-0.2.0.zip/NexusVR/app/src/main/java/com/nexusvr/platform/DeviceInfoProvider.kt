package com.nexusvr.platform

import android.Manifest
import android.app.ActivityManager
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.nexusvr.core.experience.Capability
import com.nexusvr.core.experience.DeviceCapabilities

const val HAND_MODEL_ASSET = "hand_landmarker.task"

data class DeviceInfo(
    val model: String,
    val androidRelease: String,
    val sdk: Int,
    val ramMb: Long,
    val cpuCores: Int,
    val glEsVersion: String,
    val glEsAtLeast2: Boolean,
    val hasBackCamera: Boolean,
    val hasGyroscope: Boolean,
    val hasAccelerometer: Boolean,
    val cameraPermissionGranted: Boolean,
    val handModelPresent: Boolean,
) {
    fun capabilities(): DeviceCapabilities {
        val caps = HashSet<Capability>()
        caps += Capability.TOUCH
        if (hasBackCamera) caps += Capability.CAMERA
        if (hasBackCamera && handModelPresent) caps += Capability.HAND_TRACKING
        return DeviceCapabilities(sdk, caps)
    }
}

object DeviceInfoProvider {
    fun read(context: Context): DeviceInfo {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mem = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val gl = am.deviceConfigurationInfo.reqGlEsVersion
        val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        return DeviceInfo(
            model = "${Build.MANUFACTURER} ${Build.MODEL}",
            androidRelease = Build.VERSION.RELEASE,
            sdk = Build.VERSION.SDK_INT,
            ramMb = mem.totalMem / (1024 * 1024),
            cpuCores = Runtime.getRuntime().availableProcessors(),
            glEsVersion = "${gl shr 16}.${gl and 0xFFFF}",
            glEsAtLeast2 = gl >= 0x20000,
            hasBackCamera = context.packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA),
            hasGyroscope = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE) != null,
            hasAccelerometer = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) != null,
            cameraPermissionGranted = hasCameraPermission(context),
            handModelPresent = isHandModelPresent(context),
        )
    }

    fun hasCameraPermission(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    fun isHandModelPresent(context: Context): Boolean =
        try {
            context.assets.list("")?.contains(HAND_MODEL_ASSET) == true
        } catch (e: Exception) {
            false
        }
}
