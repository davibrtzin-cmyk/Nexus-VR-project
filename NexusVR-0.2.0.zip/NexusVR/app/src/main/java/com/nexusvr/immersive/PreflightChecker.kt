package com.nexusvr.immersive

import com.nexusvr.core.settings.NexusSettings
import com.nexusvr.platform.DeviceInfo

enum class CheckStatus(val symbol: String) { OK("✓"), WARN("!"), FAIL("✗"), SKIPPED("–") }

data class PreflightItem(val label: String, val status: CheckStatus, val detail: String)

/**
 * Verificações antes de entrar na experiência. São checagens reais sobre [DeviceInfo]; nada simulado.
 * O renderizador atual é a View do Android (Canvas acelerado por GPU), não OpenGL próprio; por isso
 * a versão de GL é informativa (WARN), não bloqueante.
 */
class PreflightResult(
    val cameraHardware: PreflightItem,
    val cameraPermission: PreflightItem,
    val graphics: PreflightItem,
    val handModel: PreflightItem,
) {
    val items: List<PreflightItem> get() = listOf(cameraHardware, cameraPermission, graphics, handModel)
}

object PreflightChecker {
    fun run(info: DeviceInfo, settings: NexusSettings): PreflightResult {
        val camNeeded = settings.cameraNeeded

        val hw = when {
            !camNeeded -> PreflightItem("Câmera", CheckStatus.SKIPPED, "Não usada com as configurações atuais.")
            info.hasBackCamera -> PreflightItem("Câmera", CheckStatus.OK, "Câmera traseira disponível.")
            else -> PreflightItem("Câmera", CheckStatus.FAIL, "Este aparelho não informa câmera traseira.")
        }
        val perm = when {
            !camNeeded -> PreflightItem("Permissão da câmera", CheckStatus.SKIPPED, "Não necessária.")
            info.cameraPermissionGranted -> PreflightItem("Permissão da câmera", CheckStatus.OK, "Concedida.")
            else -> PreflightItem("Permissão da câmera", CheckStatus.WARN, "Ainda não concedida.")
        }
        val gfx = PreflightItem(
            "Gráficos",
            if (info.glEsAtLeast2) CheckStatus.OK else CheckStatus.WARN,
            "OpenGL ES ${info.glEsVersion}, ${info.ramMb} MB de RAM.",
        )
        val model = when {
            !settings.handTrackingEnabled -> PreflightItem("Modelo de mãos", CheckStatus.SKIPPED, "Rastreamento desativado.")
            info.handModelPresent -> PreflightItem("Modelo de mãos", CheckStatus.OK, "Modelo incluído no app.")
            else -> PreflightItem(
                "Modelo de mãos", CheckStatus.WARN,
                "Arquivo hand_landmarker.task ausente; a experiência abrirá só com toque.",
            )
        }
        return PreflightResult(hw, perm, gfx, model)
    }
}
