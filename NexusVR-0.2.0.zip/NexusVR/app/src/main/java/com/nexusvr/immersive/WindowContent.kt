package com.nexusvr.immersive

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import com.nexusvr.core.Box

/** Paleta/estilo compartilhado pelo desenho das janelas e dos conteúdos. */
class SpatialStyle(val density: Float) {
    var fancy: Boolean = true   // brilho e sombra; desligado em qualidade gráfica Baixa

    val bgPanel = 0xEB0E1626.toInt()
    val bgTitle = 0xFF152238.toInt()
    val accent = 0xFF3DE8FF.toInt()
    val accent2 = 0xFF7C5CFF.toInt()
    val text = 0xFFE6F1FF.toInt()
    val textDim = 0xFF8FA3BF.toInt()
    val danger = 0xFFFF5C7A.toInt()
    val hover = 0x33FFFFFF
    val pressedFill = 0x663DE8FF

    fun dp(v: Float) = v * density
    fun sp(v: Float) = v * density
}

/**
 * Conteúdo desenhado dentro do corpo de uma janela. Novos tipos de janela (vídeo, galeria,
 * navegador…) implementam esta interface e são registrados na SpatialView, sem tocar no
 * gerenciador de janelas nem no motor de interação.
 */
interface WindowContent {
    /** Desenha dentro de [body] (coordenadas da view). O canvas já está recortado ao corpo. */
    fun draw(canvas: Canvas, body: Box, style: SpatialStyle)

    /** Toque/pinça em coordenadas locais ao corpo. */
    fun onTap(localX: Float, localY: Float) {}

    fun onScroll(dy: Float) {}

    /** true => a janela precisa ser redesenhada a cada segundo (ex.: relógio). */
    val animated: Boolean get() = false

    /** A janela foi fechada: libere bitmaps e recursos. */
    fun onClose() {}
}

internal fun RectF.set(b: Box) = set(b.x, b.y, b.right, b.bottom)

internal fun Paint.fill(color: Int): Paint { style = Paint.Style.FILL; this.color = color; return this }

/**
 * Desenha [text] quebrando linhas para caber em [maxW]. Com [canvas] nulo só mede.
 * Retorna o y da linha seguinte (útil para empilhar blocos e calcular a altura total).
 */
internal fun drawWrapped(canvas: Canvas?, text: String, x: Float, y: Float, maxW: Float, paint: Paint, lineH: Float): Float {
    var yy = y
    for (para in text.split('\n')) {
        if (para.isEmpty()) { yy += lineH; continue }
        var start = 0
        while (start < para.length) {
            val n = paint.breakText(para, start, para.length, true, maxW, null).coerceAtLeast(1)
            var end = start + n
            if (end < para.length) {
                val sp = para.lastIndexOf(' ', end - 1)
                if (sp > start) end = sp + 1
            }
            canvas?.drawText(para, start, end, x, yy, paint)
            yy += lineH
            start = end
        }
    }
    return yy
}

/** Corta o texto com reticências para caber em [maxW]. */
internal fun ellipsize(paint: Paint, text: String, maxW: Float): String {
    if (paint.measureText(text) <= maxW) return text
    val n = paint.breakText(text, true, (maxW - paint.measureText("…")).coerceAtLeast(0f), null)
    return text.take(n) + "…"
}
