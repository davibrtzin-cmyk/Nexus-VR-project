package com.nexusvr.ui

import android.content.Intent
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.nexusvr.core.settings.NexusSettings
import com.nexusvr.core.settings.OrientationPref
import com.nexusvr.immersive.ImmersiveActivity
import com.nexusvr.platform.DeviceInfo
import com.nexusvr.platform.DeviceInfoProvider
import com.nexusvr.platform.SettingsRepository

/** Menu inicial. Não abre câmera nem pede permissões: isso só acontece na experiência imersiva. */
class MainActivity : ComponentActivity() {

    private lateinit var repo: SettingsRepository
    private var settings by mutableStateOf(NexusSettings())
    private lateinit var info: DeviceInfo
    private var infoState by mutableStateOf<DeviceInfo?>(null)
    private var screen by mutableStateOf(Screen.HOME)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repo = SettingsRepository(this)
        settings = repo.load()
        applyOrientation()
        refreshInfo()

        setContent {
            val inf = infoState
            NexusTheme {
                if (inf != null) {
                    BackHandler(enabled = screen != Screen.HOME) { screen = Screen.HOME }
                    when (screen) {
                        Screen.HOME -> HomeScreen(inf, settings, { startExperience(null) }) { screen = it }
                        Screen.SETTINGS -> SettingsScreen(
                            settings = settings,
                            info = inf,
                            onChange = ::update,
                            onReset = { settings = repo.reset(); applyOrientation() },
                            onOpenAppSettings = ::openAppSettings,
                            onOpenBluetooth = ::openBluetoothSettings,
                            onBack = { screen = Screen.HOME },
                        )
                        Screen.LIBRARY -> LibraryScreen(inf, { id -> startExperience(id) }) { screen = Screen.HOME }
                        Screen.ENVIRONMENTS -> EnvironmentsScreen(
                            settings = settings,
                            onSelect = { update(settings.copy(environment = it)) },
                            onBack = { screen = Screen.HOME },
                        )
                        Screen.APPS -> AppsScreen { screen = Screen.HOME }
                        Screen.HELP -> HelpScreen { screen = Screen.HOME }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshInfo()   // a permissão pode ter mudado nos ajustes do sistema
    }

    private fun refreshInfo() {
        info = DeviceInfoProvider.read(this)
        infoState = info
    }

    private fun update(s: NexusSettings) {
        settings = s
        repo.save(s)
        applyOrientation()
    }

    private fun applyOrientation() {
        // O menu fica em paisagem para refletir o uso no VR Box; segue a preferência escolhida.
        requestedOrientation = when (settings.orientation) {
            OrientationPref.SENSOR_LANDSCAPE -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            OrientationPref.LANDSCAPE -> ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            OrientationPref.REVERSE_LANDSCAPE -> ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE
        }
    }

    private fun startExperience(experienceId: String?) {
        val i = Intent(this, ImmersiveActivity::class.java)
        if (experienceId != null) i.putExtra(ImmersiveActivity.EXTRA_EXPERIENCE_ID, experienceId)
        startActivity(i)
    }

    private fun openBluetoothSettings() {
        try {
            startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
        } catch (e: Exception) {
            // aparelho sem essa tela: o usuário pareia pelos ajustes do sistema
        }
    }

    private fun openAppSettings() {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null)))
    }
}
