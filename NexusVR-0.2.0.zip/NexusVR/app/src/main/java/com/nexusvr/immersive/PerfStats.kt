package com.nexusvr.immersive

import android.os.SystemClock

/** Medições reais do rastreamento (para a seção de diagnóstico; nada é exibido a cada gesto). */
class PerfStats {
    @Volatile var fps = 0f
        private set
    @Volatile var latencyMs = 0f
        private set
    @Volatile var results = 0L
        private set

    private var lastAt = 0L

    /** [latency] = tempo entre enviar o quadro ao MediaPipe e receber o resultado. */
    fun onResult(latency: Long) {
        val now = SystemClock.uptimeMillis()
        if (lastAt > 0L) {
            val inst = 1000f / (now - lastAt).coerceAtLeast(1L)
            fps = if (fps == 0f) inst else fps * 0.9f + inst * 0.1f
        }
        lastAt = now
        val l = latency.coerceAtLeast(0L).toFloat()
        latencyMs = if (latencyMs == 0f) l else latencyMs * 0.9f + l * 0.1f
        results++
    }
}
