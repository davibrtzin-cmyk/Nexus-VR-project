package com.nexusvr.immersive

import android.graphics.Bitmap
import android.os.SystemClock
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy

/**
 * Ponte CameraX → HandTracker. Roda na thread do executor de análise (nunca na UI).
 * - Limita a frequência ao FPS configurado (descarta o excesso sem processar).
 * - Reutiliza bitmaps quando o buffer é compacto; só aloca (toBitmap) no caso de stride com padding.
 */
class HandFrameAnalyzer(
    private val tracker: HandTracker,
    fps: Int,
    /** Informa o tamanho da imagem "em pé" (já considerando a rotação) quando ele muda. */
    private val onGeometry: (width: Int, height: Int) -> Unit,
) : ImageAnalysis.Analyzer {

    private val minIntervalMs = 1000L / fps.coerceAtLeast(1)
    private var lastProcessedAt = 0L
    private val pool = arrayOfNulls<Bitmap>(2)
    private var poolIndex = 0
    private var geoW = 0
    private var geoH = 0

    override fun analyze(image: ImageProxy) {
        try {
            val now = SystemClock.uptimeMillis()
            if (now - lastProcessedAt < minIntervalMs) return
            lastProcessedAt = now

            val rotation = image.imageInfo.rotationDegrees
            val upW = if (rotation % 180 == 0) image.width else image.height
            val upH = if (rotation % 180 == 0) image.height else image.width
            if (upW != geoW || upH != geoH) {
                geoW = upW; geoH = upH
                onGeometry(upW, upH)
            }

            val plane = image.planes[0]
            val bitmap = if (plane.pixelStride == 4 && plane.rowStride == image.width * 4) {
                val b = obtain(image.width, image.height)
                plane.buffer.rewind()
                b.copyPixelsFromBuffer(plane.buffer)
                b
            } else {
                image.toBitmap()
            }
            tracker.detect(bitmap, rotation)
        } catch (_: Throwable) {
            // Um quadro ruim não deve derrubar o fluxo; o próximo quadro tenta de novo.
        } finally {
            image.close()
        }
    }

    private fun obtain(w: Int, h: Int): Bitmap {
        poolIndex = (poolIndex + 1) % pool.size
        var b = pool[poolIndex]
        if (b == null || b.width != w || b.height != h || b.isRecycled) {
            b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            pool[poolIndex] = b
        }
        return b
    }
}
