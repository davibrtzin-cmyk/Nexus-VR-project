package com.nexusvr.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

enum class ModuleState(val label: String, val color: Color) {
    READY("Pronto", Nx.ok),
    EXPERIMENTAL("Experimental", Nx.warn),
    IN_DEVELOPMENT("Em desenvolvimento", Nx.dim),
}

@Composable
fun StatusDot(color: Color) {
    Box(Modifier.size(9.dp).clip(CircleShape).background(color))
}

@Composable
fun StateChip(state: ModuleState) {
    Row(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(state.color.copy(alpha = 0.14f))
            .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        StatusDot(state.color)
        Spacer(Modifier.size(6.dp))
        Text(state.label, color = state.color, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun NexusButton(label: String, onClick: () -> Unit, primary: Boolean = false, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(16.dp)
    Box(
        modifier
            .clip(shape)
            .then(
                if (primary) Modifier.background(Brush.horizontalGradient(listOf(Nx.cyan, Nx.violet)))
                else Modifier.background(Nx.panelHi).border(BorderStroke(1.dp, Nx.line), shape),
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label,
            color = if (primary) Color(0xFF07101C) else Nx.text,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            letterSpacing = 1.sp,
        )
    }
}

/** Cartão de módulo do menu: título, estado e descrição. Sempre leva a uma tela real. */
@Composable
fun ModuleCard(title: String, subtitle: String, state: ModuleState, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(18.dp)
    Column(
        modifier
            .clip(shape)
            .background(Nx.panel)
            .border(BorderStroke(1.dp, Nx.line), shape)
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(title, color = Nx.text, fontWeight = FontWeight.Bold, fontSize = 14.sp, letterSpacing = 1.sp)
        Text(subtitle, color = Nx.dim, fontSize = 12.sp, lineHeight = 16.sp)
        StateChip(state)
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text.uppercase(),
        color = Nx.cyan,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 2.sp,
        modifier = Modifier.padding(top = 20.dp, bottom = 8.dp),
    )
}

@Composable
fun SettingRow(title: String, description: String?, content: @Composable () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Nx.text, fontSize = 15.sp)
            if (description != null) Text(description, color = Nx.dim, fontSize = 12.sp, lineHeight = 16.sp)
        }
        Spacer(Modifier.size(12.dp))
        content()
    }
}

@Composable
fun SwitchRow(title: String, description: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    SettingRow(title, description) {
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = Nx.cyan, checkedThumbColor = Color.White),
        )
    }
}

@Composable
fun SliderRow(title: String, description: String?, value: Float, onChange: (Float) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Text(title, color = Nx.text, fontSize = 15.sp)
        if (description != null) Text(description, color = Nx.dim, fontSize = 12.sp)
        Slider(
            value = value,
            onValueChange = onChange,
            colors = SliderDefaults.colors(thumbColor = Nx.cyan, activeTrackColor = Nx.cyan),
        )
    }
}

/** Seletor de opção única em linha, com os rótulos de cada valor. */
@Composable
fun <T> ChoiceRow(title: String, description: String?, options: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Text(title, color = Nx.text, fontSize = 15.sp)
        if (description != null) Text(description, color = Nx.dim, fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (o in options) {
                val on = o == selected
                val shape = RoundedCornerShape(12.dp)
                Box(
                    Modifier
                        .weight(1f)
                        .clip(shape)
                        .background(if (on) Nx.cyan.copy(alpha = 0.18f) else Nx.panelHi)
                        .border(BorderStroke(1.dp, if (on) Nx.cyan else Nx.line), shape)
                        .clickable { onSelect(o) }
                        .padding(vertical = 10.dp, horizontal = 6.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(label(o), color = if (on) Nx.cyan else Nx.text, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun InfoLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
        Text(label, color = Nx.dim, fontSize = 13.sp, modifier = Modifier.weight(0.45f))
        Text(value, color = Nx.text, fontSize = 13.sp, modifier = Modifier.weight(0.55f))
    }
}
