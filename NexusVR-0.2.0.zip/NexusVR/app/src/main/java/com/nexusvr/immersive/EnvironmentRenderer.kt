package com.nexusvr.immersive

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import com.nexusvr.core.environment.StarField
import com.nexusvr.core.settings.EnvironmentId
import kotlin.math.PI
import kotlin.math.sin

/**
 * Desenha os ambientes virtuais por código (nenhum arquivo de imagem) numa única Bitmap em cache,
 * refeita só quando ambiente, tamanho ou qualidade mudam. Em qualidade Baixa usa metade da
 * resolução (mais leve para CPU, memória e bateria).
 */
class EnvironmentRenderer {
    private var bmp: Bitmap? = null
    private var key = ""
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    fun get(env: EnvironmentId, w: Int, h: Int, fancy: Boolean): Bitmap? {
        if (w <= 0 || h <= 0) return null
        val k = "${env.name}:$w:$h:$fancy"
        if (k == key) return bmp
        val scale = if (fancy) 1f else 0.5f
        val bw = (w * scale).toInt().coerceAtLeast(1)
        val bh = (h * scale).toInt().coerceAtLeast(1)
        val b = try {
            Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        } catch (e: OutOfMemoryError) {
            return bmp
        }
        render(Canvas(b), env, bw.toFloat(), bh.toFloat(), fancy)
        val old = bmp
        bmp = b
        key = k
        old?.recycle()
        return b
    }

    fun release() {
        bmp?.recycle()
        bmp = null
        key = ""
    }

    private fun render(c: Canvas, env: EnvironmentId, w: Float, h: Float, fancy: Boolean) {
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, 0f, h, env.top, env.bottom, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null
        when (env) {
            EnvironmentId.SPACE -> stars(c, w, h, if (fancy) 240 else 90, 7L)
            EnvironmentId.GRID -> grid(c, w, h, fancy)
            EnvironmentId.AURORA -> { stars(c, w, h, 80, 11L); aurora(c, w, h, fancy) }
            EnvironmentId.DUSK -> dusk(c, w, h)
        }
    }

    private fun stars(c: Canvas, w: Float, h: Float, count: Int, seed: Long) {
        val s = StarField.generate(seed, count)
        val unit = (h / 360f).coerceAtLeast(0.5f)
        p.style = Paint.Style.FILL
        for (i in 0 until count) {
            val b = s[i * 3 + 2]
            p.color = Color.argb((b * 255f).toInt(), 255, 255, 255)
            c.drawCircle(s[i * 3] * w, s[i * 3 + 1] * h, (0.6f + b * 1.4f) * unit, p)
        }
    }

    private fun grid(c: Canvas, w: Float, h: Float, fancy: Boolean) {
        val horizon = h * 0.55f
        if (fancy) {
            val cy = horizon - h * 0.1f
            val r = h * 0.16f
            p.shader = RadialGradient(w / 2f, cy, r, 0xFFFFC857.toInt(), 0x00FF3DCB, Shader.TileMode.CLAMP)
            c.drawCircle(w / 2f, cy, r, p)
            p.shader = null
        }
        p.shader = LinearGradient(0f, horizon, 0f, h, 0xFF0A0420.toInt(), 0xFF2A0F5A.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(0f, horizon, w, h, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = (h / 360f * 1.5f).coerceAtLeast(1f)
        p.color = 0xCCFF3DCB.toInt()
        for (i in 1..10) {
            val t = i / 10f
            val y = horizon + (h - horizon) * t * t
            c.drawLine(0f, y, w, y, p)
        }
        p.color = 0x993DE8FF.toInt()
        for (k in -12..12) {
            c.drawLine(w / 2f + k * w * 0.01f, horizon, w / 2f + k * w * 0.1f, h, p)
        }
        p.color = 0xCCFF3DCB.toInt()
        c.drawLine(0f, horizon, w, horizon, p)
        p.style = Paint.Style.FILL
    }

    private fun aurora(c: Canvas, w: Float, h: Float, fancy: Boolean) {
        val bands = if (fancy) 3 else 2
        val colors = intArrayOf(0xFF3DDC97.toInt(), 0xFF3DE8FF.toInt(), 0xFF7C5CFF.toInt())
        p.style = Paint.Style.FILL
        for (b in 0 until bands) {
            val y0 = h * (0.2f + 0.13f * b)
            val thick = h * 0.22f
            val path = Path()
            path.moveTo(0f, y0)
            var x = 0f
            while (x <= w) {
                path.lineTo(x, y0 + sin(x / w * 2f * PI.toFloat() * 1.5f + b * 1.7f) * h * 0.05f)
                x += (w / 60f).coerceAtLeast(4f)
            }
            path.lineTo(w, y0 + thick)
            path.lineTo(0f, y0 + thick)
            path.close()
            val col = colors[b % colors.size]
            p.shader = LinearGradient(0f, y0, 0f, y0 + thick, (col and 0x00FFFFFF) or 0x99000000.toInt(), col and 0x00FFFFFF, Shader.TileMode.CLAMP)
            c.drawPath(path, p)
            p.shader = null
        }
    }

    private fun dusk(c: Canvas, w: Float, h: Float) {
        val cy = h * 0.62f
        val r = h * 0.22f
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(w / 2f, cy, r, 0xFFFFC857.toInt(), 0x00FF7A59, Shader.TileMode.CLAMP)
        c.drawCircle(w / 2f, cy, r, p)
        p.shader = null
        p.color = 0xFF120A1E.toInt()
        c.drawRect(0f, h * 0.66f, w, h, p)
        p.color = 0x66FFC857
        c.drawRect(0f, h * 0.66f - 1f, w, h * 0.66f + 2f, p)
    }
}
