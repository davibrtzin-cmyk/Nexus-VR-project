package com.nexusvr.immersive

import android.content.Context
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.core.UseCase
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Abre a câmera TRASEIRA real via CameraX. Preview e análise são casos de uso independentes:
 * sem preview (fundo desligado) não há custo de exibição; sem analisador (mãos desligadas)
 * não há processamento de visão. [stop] libera tudo.
 */
class CameraController(private val context: Context) {
    private var provider: ProcessCameraProvider? = null
    private var executor: ExecutorService? = null
    private var preview: Preview? = null
    private var analysis: ImageAnalysis? = null
    private var generation = 0

    fun start(
        owner: LifecycleOwner,
        previewView: PreviewView?,
        analyzer: ImageAnalysis.Analyzer?,
        analysisSize: Size,
        rotation: Int,
        onError: (String) -> Unit,
    ) {
        if (previewView == null && analyzer == null) return
        val gen = ++generation
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            if (gen != generation) return@addListener   // stop() chamado antes da câmera ficar pronta
            try {
                val p = future.get()
                provider = p
                val useCases = ArrayList<UseCase>(2)

                if (previewView != null) {
                    val pv = Preview.Builder()
                        .setResolutionSelector(
                            ResolutionSelector.Builder()
                                .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
                                .build(),
                        )
                        .setTargetRotation(rotation)
                        .build()
                    pv.setSurfaceProvider(previewView.surfaceProvider)
                    preview = pv
                    useCases += pv
                }
                if (analyzer != null) {
                    val exec = Executors.newSingleThreadExecutor()
                    executor = exec
                    val an = ImageAnalysis.Builder()
                        .setResolutionSelector(
                            ResolutionSelector.Builder()
                                .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
                                .setResolutionStrategy(
                                    ResolutionStrategy(analysisSize, ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER),
                                )
                                .build(),
                        )
                        .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .setTargetRotation(rotation)
                        .build()
                    an.setAnalyzer(exec, analyzer)
                    analysis = an
                    useCases += an
                }

                p.unbindAll()
                p.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, *useCases.toTypedArray())
            } catch (t: Throwable) {
                onError(t.message ?: "Não foi possível abrir a câmera")
            }
        }, ContextCompat.getMainExecutor(context))
    }

    fun setTargetRotation(rotation: Int) {
        preview?.targetRotation = rotation
        analysis?.targetRotation = rotation
    }

    fun stop() {
        generation++
        try {
            analysis?.clearAnalyzer()
            provider?.unbindAll()
        } catch (_: Throwable) {
        }
        executor?.shutdown()
        executor = null
        analysis = null
        preview = null
        provider = null
    }
}
