package com.nexusvr.core.input

import kotlin.math.abs
import kotlin.math.hypot

/**
 * Cursor controlado por gamepad/teclado Bluetooth (analógico ou direcional + botão de seleção).
 * Gera os mesmos [PointerEvent] que a mão e o toque (fonte [InputSource.KEY]), então janelas e
 * botões respondem sem nenhuma lógica extra. Lógica pura: o relógio vem de quem chama [update].
 */
class ControllerCursor(
    /** Velocidade máxima do cursor com o analógico no fim do curso. */
    var speedPxPerSec: Float = 650f,
    private val deadzone: Float = 0.2f,
) {
    var x = 0f
        private set
    var y = 0f
        private set

    private var w = 0f
    private var h = 0f
    private var placed = false
    private var ax = 0f
    private var ay = 0f
    private var dx = 0
    private var dy = 0
    private var pressed = false

    val isPressed: Boolean get() = pressed

    /** Algo exige quadros periódicos (analógico fora da zona morta ou direcional apertado). */
    val isActive: Boolean get() = ax != 0f || ay != 0f || dx != 0 || dy != 0

    fun setBounds(width: Float, height: Float) {
        if (width <= 0f || height <= 0f) return
        w = width; h = height
        if (!placed) { x = w / 2f; y = h / 2f }
        x = x.coerceIn(0f, w)
        y = y.coerceIn(0f, h)
    }

    /** Eixos analógicos em -1..1 (esquerda/cima negativos). Aplica zona morta com reescala. */
    fun setAxes(rawX: Float, rawY: Float) {
        ax = dead(rawX)
        ay = dead(rawY)
    }

    /** Direcional digital: -1, 0 ou 1 em cada eixo. */
    fun setDpad(dirX: Int, dirY: Int) {
        dx = dirX.coerceIn(-1, 1)
        dy = dirY.coerceIn(-1, 1)
    }

    /** Botão de seleção apertado/solto. Só emite evento quando o estado muda. */
    fun onButton(down: Boolean): List<PointerEvent> {
        if (w <= 0f || down == pressed) return emptyList()
        pressed = down
        placed = true
        return if (down) {
            listOf(PointerMove(x, y, InputSource.KEY), PointerDown(x, y, InputSource.KEY))
        } else {
            listOf(PointerUp(x, y, InputSource.KEY))
        }
    }

    /** Avança o cursor [dtMs] milissegundos. Sem movimento => lista vazia. */
    fun update(dtMs: Long): List<PointerEvent> {
        if (w <= 0f || !isActive) return emptyList()
        var vx = ax + dx
        var vy = ay + dy
        val mag = hypot(vx, vy)
        if (mag > 1f) { vx /= mag; vy /= mag }
        val step = speedPxPerSec * dtMs.coerceIn(0L, 50L) / 1000f
        val nx = (x + vx * step).coerceIn(0f, w)
        val ny = (y + vy * step).coerceIn(0f, h)
        placed = true
        if (nx == x && ny == y) return emptyList()
        x = nx; y = ny
        return listOf(PointerMove(x, y, InputSource.KEY))
    }

    /** Perda de foco/controle desconectado: cancela uma pressão em andamento e para o movimento. */
    fun release(): List<PointerEvent> {
        ax = 0f; ay = 0f; dx = 0; dy = 0
        if (!pressed) return emptyList()
        pressed = false
        return listOf(PointerCancel(x, y, InputSource.KEY))
    }

    private fun dead(v: Float): Float {
        if (v.isNaN()) return 0f
        val a = abs(v).coerceAtMost(1f)
        if (a < deadzone) return 0f
        val scaled = (a - deadzone) / (1f - deadzone)
        return if (v < 0f) -scaled else scaled
    }
}
