package com.nexusvr.core.window

import com.nexusvr.core.Box
import com.nexusvr.core.input.InputSource
import com.nexusvr.core.input.PointerCancel
import com.nexusvr.core.input.PointerDown
import com.nexusvr.core.input.PointerEvent
import com.nexusvr.core.input.PointerExit
import com.nexusvr.core.input.PointerMove
import com.nexusvr.core.input.PointerUp
import kotlin.math.hypot

/** Botão fixo da interface (fora das janelas), ex.: voltar ao menu. */
class HudButton(val id: String, var box: Box)

interface InteractionListener {
    fun onBodyTap(window: VirtualWindow, localX: Float, localY: Float) {}

    /** [dy] = deslocamento do ponteiro; o conteúdo normalmente acompanha o dedo (offset -= dy). */
    fun onBodyScroll(window: VirtualWindow, dy: Float) {}

    fun onHudButton(id: String) {}
}

/**
 * Traduz eventos de ponteiro (mão, toque, tecla) em ações sobre janelas: focar, arrastar pela
 * barra de título, redimensionar pela alça, fechar/minimizar/restaurar, tocar e rolar o corpo.
 * Ações de botão só disparam ao SOLTAR sobre o mesmo alvo em que se pressionou, o que evita
 * cliques acidentais e duplicados. Não exibe nenhuma mensagem: o estado visual (hover/pressed)
 * é apenas exposto para o desenho.
 */
class WindowInteractor(
    private val wm: WindowManager,
    private val slopPx: Float = 24f,
) {
    val hudButtons = ArrayList<HudButton>()
    var listener: InteractionListener? = null
    var onChanged: (() -> Unit)? = null

    var cursorX = 0f
        private set
    var cursorY = 0f
        private set
    var cursorVisible = false
        private set
    var cursorSource = InputSource.TOUCH
        private set
    var pressed = false
        private set
    var hoverHit = Hit.NONE
        private set
    var hoverHud: String? = null
        private set
    var pressedHit = Hit.NONE
        private set
    var pressedHud: String? = null
        private set

    private enum class Mode { IDLE, DRAG, RESIZE, ARMED, SCROLL }

    private var mode = Mode.IDLE
    private var startX = 0f
    private var startY = 0f
    private var lastY = 0f
    private var grabX = 0f
    private var grabY = 0f

    fun onEvent(e: PointerEvent) {
        when (e) {
            is PointerMove -> onMove(e)
            is PointerDown -> onDown(e)
            is PointerUp -> onUp(e)
            is PointerCancel -> endPress()
            is PointerExit -> {
                endPress()
                cursorVisible = false
                hoverHit = Hit.NONE
                hoverHud = null
            }
        }
        onChanged?.invoke()
    }

    private fun setCursor(e: PointerEvent) {
        cursorX = e.x; cursorY = e.y; cursorSource = e.source; cursorVisible = true
    }

    private fun hudAt(x: Float, y: Float): String? = hudButtons.firstOrNull { it.box.contains(x, y) }?.id

    private fun updateHover(x: Float, y: Float) {
        hoverHud = hudAt(x, y)
        hoverHit = if (hoverHud != null) Hit.NONE else wm.hitTest(x, y)
    }

    private fun endPress() {
        mode = Mode.IDLE
        pressed = false
        pressedHit = Hit.NONE
        pressedHud = null
    }

    private fun onMove(e: PointerMove) {
        setCursor(e)
        when (mode) {
            Mode.DRAG -> wm.moveTo(pressedHit.windowId, e.x - grabX, e.y - grabY)
            Mode.RESIZE -> {
                val w = wm.get(pressedHit.windowId)
                if (w != null) wm.resizeTo(w.id, e.x + grabX - w.box.x, e.y + grabY - w.box.y)
            }
            Mode.ARMED -> {
                if (pressedHit.part == Part.BODY && hypot(e.x - startX, e.y - startY) > slopPx) {
                    mode = Mode.SCROLL
                    lastY = startY
                    scrollTo(e.y)
                }
            }
            Mode.SCROLL -> scrollTo(e.y)
            Mode.IDLE -> {}
        }
        if (!pressed) updateHover(e.x, e.y)
    }

    private fun scrollTo(y: Float) {
        val w = wm.get(pressedHit.windowId) ?: return
        val dy = y - lastY
        lastY = y
        if (dy != 0f) listener?.onBodyScroll(w, dy)
    }

    private fun onDown(e: PointerDown) {
        setCursor(e)
        pressed = true
        startX = e.x; startY = e.y; lastY = e.y

        val hud = hudAt(e.x, e.y)
        if (hud != null) {
            pressedHud = hud; pressedHit = Hit.NONE; mode = Mode.ARMED
            return
        }
        pressedHud = null
        val hit = wm.hitTest(e.x, e.y)
        pressedHit = hit
        if (hit.windowId >= 0 && hit.part != Part.DOCK) wm.focus(hit.windowId)

        val w = wm.get(hit.windowId)
        mode = when {
            hit.part == Part.NONE || w == null -> Mode.IDLE
            hit.part == Part.TITLE -> {
                grabX = e.x - w.box.x; grabY = e.y - w.box.y
                Mode.DRAG
            }
            hit.part == Part.RESIZE -> {
                grabX = w.box.right - e.x; grabY = w.box.bottom - e.y
                Mode.RESIZE
            }
            else -> Mode.ARMED
        }
    }

    private fun onUp(e: PointerUp) {
        setCursor(e)
        if (mode == Mode.ARMED) {
            val hudId = pressedHud
            if (hudId != null) {
                if (hudAt(e.x, e.y) == hudId) listener?.onHudButton(hudId)
            } else {
                val hit = wm.hitTest(e.x, e.y)
                if (hit == pressedHit) activate(hit, e)
            }
        }
        endPress()
        updateHover(e.x, e.y)
    }

    private fun activate(hit: Hit, e: PointerEvent) {
        val w = wm.get(hit.windowId) ?: return
        when (hit.part) {
            Part.CLOSE -> wm.close(w.id)
            Part.MINIMIZE -> wm.minimize(w.id)
            Part.DOCK -> wm.restore(w.id)
            Part.BODY -> {
                val body = wm.bodyBox(w)
                listener?.onBodyTap(w, e.x - body.x, e.y - body.y)
            }
            else -> {}
        }
    }
}
