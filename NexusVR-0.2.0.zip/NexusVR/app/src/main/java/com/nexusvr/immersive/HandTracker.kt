package com.nexusvr.immersive

import android.content.Context
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.ImageProcessingOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import com.nexusvr.core.gesture.Lm
import com.nexusvr.platform.HAND_MODEL_ASSET

/**
 * Detecção de mão real via MediaPipe HandLandmarker (on-device, modo LIVE_STREAM, CPU).
 * Esta classe só produz landmarks; reconhecer gestos é com o GestureEngine e agir sobre a
 * interface é com o WindowInteractor — três camadas independentes.
 *
 * Os callbacks de [Listener] são entregues na thread principal.
 */
class HandTracker(
    context: Context,
    private val perf: PerfStats,
    private val listener: Listener,
) : AutoCloseable {

    interface Listener {
        /** [landmarks] = 21 pontos × (x,y,z) normalizados na imagem "em pé"; null = nenhuma mão. */
        fun onHand(landmarks: FloatArray?, timestampMs: Long)
        fun onError(message: String)
    }

    private val main = Handler(Looper.getMainLooper())
    private val lock = Any()
    @Volatile private var closed = false
    private var landmarker: HandLandmarker? = null
    private var lastTs = 0L

    init {
        val base = BaseOptions.builder().setModelAssetPath(HAND_MODEL_ASSET).build()
        val options = HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(base)
            .setRunningMode(RunningMode.LIVE_STREAM)
            .setNumHands(1)
            .setMinHandDetectionConfidence(0.5f)
            .setMinHandPresenceConfidence(0.5f)
            .setMinTrackingConfidence(0.5f)
            .setResultListener { result, _ -> onResult(result) }
            .setErrorListener { e ->
                main.post { if (!closed) listener.onError(e.message ?: "Erro no rastreamento de mãos") }
            }
            .build()
        landmarker = HandLandmarker.createFromOptions(context.applicationContext, options)
    }

    /** Chamado pela thread do analisador de câmera. Não bloqueia esperando o resultado. */
    fun detect(bitmap: Bitmap, rotationDegrees: Int) {
        synchronized(lock) {
            val lm = landmarker ?: return
            if (closed) return
            var ts = SystemClock.uptimeMillis()
            if (ts <= lastTs) ts = lastTs + 1   // LIVE_STREAM exige timestamps crescentes
            lastTs = ts
            try {
                val image = BitmapImageBuilder(bitmap).build()
                val opts = ImageProcessingOptions.builder().setRotationDegrees(rotationDegrees).build()
                lm.detectAsync(image, opts, ts)
            } catch (e: Exception) {
                main.post { if (!closed) listener.onError(e.message ?: "Falha ao enviar quadro") }
            }
        }
    }

    private fun onResult(result: HandLandmarkerResult) {
        if (closed) return
        perf.onResult(SystemClock.uptimeMillis() - result.timestampMs())
        val hands = result.landmarks()
        var arr: FloatArray? = null
        if (hands.isNotEmpty() && hands[0].size >= Lm.COUNT) {
            val h = hands[0]
            val a = FloatArray(Lm.COUNT * 3)
            for (i in 0 until Lm.COUNT) {
                val p = h[i]
                a[i * 3] = p.x(); a[i * 3 + 1] = p.y(); a[i * 3 + 2] = p.z()
            }
            arr = a
        }
        val ts = result.timestampMs()
        main.post { if (!closed) listener.onHand(arr, ts) }
    }

    override fun close() {
        synchronized(lock) {
            closed = true
            try {
                landmarker?.close()
            } catch (_: Exception) {
            }
            landmarker = null
        }
        main.removeCallbacksAndMessages(null)
    }
}
