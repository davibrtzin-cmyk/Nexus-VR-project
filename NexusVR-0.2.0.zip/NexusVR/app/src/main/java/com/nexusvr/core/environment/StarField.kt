package com.nexusvr.core.environment

/**
 * Estrelas pseudoaleatórias DETERMINÍSTICAS (mesma semente => mesmo céu), para o fundo não "piscar"
 * quando é redesenhado. Retorna triplas (x, y, brilho), todas em 0..1.
 */
object StarField {
    fun generate(seed: Long, count: Int): FloatArray {
        val n = count.coerceAtLeast(0)
        val out = FloatArray(n * 3)
        var s = seed
        fun next(): Float {
            s = s * 6364136223846793005L + 1442695040888963407L
            return ((s ushr 40) and 0xFFFFFFL).toInt() / 16777216f
        }
        for (i in 0 until n) {
            out[i * 3] = next()
            out[i * 3 + 1] = next()
            out[i * 3 + 2] = 0.35f + 0.65f * next()
        }
        return out
    }
}
