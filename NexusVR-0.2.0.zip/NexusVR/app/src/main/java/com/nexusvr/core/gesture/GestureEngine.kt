package com.nexusvr.core.gesture

import com.nexusvr.core.Vec2
import com.nexusvr.core.input.InputSource
import com.nexusvr.core.input.PointerCancel
import com.nexusvr.core.input.PointerDown
import com.nexusvr.core.input.PointerEvent
import com.nexusvr.core.input.PointerExit
import com.nexusvr.core.input.PointerMove
import com.nexusvr.core.input.PointerUp
import kotlin.math.hypot

/** Índices dos landmarks da mão (convenção MediaPipe, 21 pontos). */
object Lm {
    const val WRIST = 0
    const val THUMB_TIP = 4
    const val INDEX_TIP = 8
    const val MIDDLE_MCP = 9
    const val COUNT = 21
}

class GestureConfig(
    /** 0..1. Maior = pinça dispara mais fácil (limiar de fechamento maior). */
    var sensitivity: Float = 0.5f,
    /** Quadros consecutivos "fechados" antes de emitir PointerDown (filtra ruído). */
    var confirmFrames: Int = 2,
    /** Quadros consecutivos "abertos" antes de emitir PointerUp. */
    var releaseFrames: Int = 2,
    /** Sem mão por este tempo => cancela pinça em andamento / esconde cursor. */
    var lostTimeoutMs: Long = 300,
    /** Após um PointerUp, ignora novo PointerDown por este tempo (evita clique duplo). */
    var debounceMs: Long = 150,
    /** largura/altura da imagem analisada; corrige a distorção das coordenadas normalizadas. */
    var imageAspect: Float = 1f,
)

/**
 * Transforma landmarks de mão em eventos de ponteiro. Lógica pura: sem Android, sem threads.
 * Deve ser chamada sempre da mesma thread (a de UI, no app).
 *
 * Ponteiro: ponto médio entre a ponta do polegar e a do indicador (estável durante a pinça,
 * pois os dois dedos se encontram ali).
 * Pinça: distância polegar–indicador dividida pelo tamanho da mão (pulso→base do dedo médio),
 * com histerese (limiar de abertura > limiar de fechamento).
 */
class GestureEngine(
    val config: GestureConfig = GestureConfig(),
    var mapper: (Float, Float) -> Vec2 = { nx, ny -> Vec2(nx, ny) },
) {
    var lastPinchRatio: Float = Float.NaN
        private set
    val isPressed: Boolean get() = pressed

    private var pressed = false
    private var below = 0
    private var above = 0
    private var lastUpAt = Long.MIN_VALUE / 2
    private var lastSeenAt = Long.MIN_VALUE / 2
    private var hasPos = false
    private var sx = 0f
    private var sy = 0f

    fun reset() {
        pressed = false; below = 0; above = 0; hasPos = false
        lastUpAt = Long.MIN_VALUE / 2; lastSeenAt = Long.MIN_VALUE / 2
        lastPinchRatio = Float.NaN
    }

    /** [landmarks] = x,y,z de 21 pontos (63 floats) normalizados; null/curto = nenhuma mão. */
    fun onFrame(landmarks: FloatArray?, nowMs: Long): List<PointerEvent> {
        val out = ArrayList<PointerEvent>(3)
        if (landmarks == null || landmarks.size < Lm.COUNT * 3) {
            handleAbsent(nowMs, out)
            return out
        }

        val a = config.imageAspect
        val tx = landmarks[Lm.THUMB_TIP * 3]
        val ty = landmarks[Lm.THUMB_TIP * 3 + 1]
        val ix = landmarks[Lm.INDEX_TIP * 3]
        val iy = landmarks[Lm.INDEX_TIP * 3 + 1]
        val wx = landmarks[Lm.WRIST * 3]
        val wy = landmarks[Lm.WRIST * 3 + 1]
        val mx = landmarks[Lm.MIDDLE_MCP * 3]
        val my = landmarks[Lm.MIDDLE_MCP * 3 + 1]

        val handSize = hypot((wx - mx) * a, wy - my)
        if (handSize < 1e-4f) {
            handleAbsent(nowMs, out)
            return out
        }
        lastSeenAt = nowMs
        val ratio = hypot((tx - ix) * a, ty - iy) / handSize
        lastPinchRatio = ratio

        // Posição suavizada: filtro exponencial adaptativo (mais suave parado, mais ágil em movimento).
        val p = mapper((tx + ix) / 2f, (ty + iy) / 2f)
        if (!hasPos) {
            sx = p.x; sy = p.y; hasPos = true
        } else {
            val d = hypot(p.x - sx, p.y - sy)
            val alpha = (0.25f + d / 200f).coerceIn(0.25f, 0.85f)
            sx += (p.x - sx) * alpha
            sy += (p.y - sy) * alpha
        }
        out += PointerMove(sx, sy, InputSource.HAND)

        val on = 0.22f + 0.18f * config.sensitivity.coerceIn(0f, 1f)
        val off = on * 1.35f
        if (!pressed) {
            if (ratio < on) below++ else below = 0
            if (below >= config.confirmFrames && nowMs - lastUpAt >= config.debounceMs) {
                pressed = true; below = 0; above = 0
                out += PointerDown(sx, sy, InputSource.HAND)
            }
        } else {
            if (ratio > off) above++ else above = 0
            if (above >= config.releaseFrames) {
                pressed = false; above = 0; below = 0; lastUpAt = nowMs
                out += PointerUp(sx, sy, InputSource.HAND)
            }
        }
        return out
    }

    private fun handleAbsent(nowMs: Long, out: MutableList<PointerEvent>) {
        if (!hasPos) return
        if (nowMs - lastSeenAt < config.lostTimeoutMs) return
        if (pressed) {
            out += PointerCancel(sx, sy, InputSource.HAND)
            pressed = false
        }
        out += PointerExit(sx, sy, InputSource.HAND)
        hasPos = false; below = 0; above = 0
        lastPinchRatio = Float.NaN
    }
}
