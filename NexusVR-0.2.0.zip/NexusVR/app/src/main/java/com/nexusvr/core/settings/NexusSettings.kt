package com.nexusvr.core.settings

enum class GraphicsQuality(val label: String) {
    LOW("Baixa"), MEDIUM("Média"), HIGH("Alta")
}

enum class AnalysisResolution(val w: Int, val h: Int, val label: String) {
    R320(320, 240, "320×240 (mais leve)"),
    R480(480, 360, "480×360"),
    R640(640, 480, "640×480 (mais preciso)"),
}

enum class OrientationPref(val label: String) {
    SENSOR_LANDSCAPE("Paisagem automática"),
    LANDSCAPE("Paisagem fixa"),
    REVERSE_LANDSCAPE("Paisagem invertida"),
}

enum class ViewMode(val label: String) {
    NORMAL("Normal"), STEREO("VR Box")
}

/** Ambientes virtuais desenhados por código (sem arquivos pesados). As cores servem ao desenho e às prévias. */
enum class EnvironmentId(val label: String, val description: String, val top: Int, val bottom: Int) {
    SPACE("Espaço", "Céu escuro com estrelas.", 0xFF02040A.toInt(), 0xFF0B1530.toInt()),
    GRID("Grade", "Chão em grade neon sob um céu roxo.", 0xFF07051A.toInt(), 0xFF1A0B3D.toInt()),
    AURORA("Aurora", "Faixas de luz verde e azul no céu.", 0xFF03130F.toInt(), 0xFF0B2A3A.toInt()),
    DUSK("Crepúsculo", "Horizonte quente com sol baixo.", 0xFF1B1030.toInt(), 0xFF5A2A4A.toInt());

    fun next(): EnvironmentId = entries[(ordinal + 1) % entries.size]
}

data class NexusSettings(
    val graphicsQuality: GraphicsQuality = GraphicsQuality.MEDIUM,
    val analysisResolution: AnalysisResolution = AnalysisResolution.R320,
    val analysisFps: Int = 15,
    val handTrackingEnabled: Boolean = true,
    val gestureSensitivity: Float = 0.5f,
    val showHandSkeleton: Boolean = false,
    val cameraBackground: Boolean = true,
    val orientation: OrientationPref = OrientationPref.SENSOR_LANDSCAPE,
    val showDiagnostics: Boolean = false,
    val viewMode: ViewMode = ViewMode.NORMAL,
    val environment: EnvironmentId = EnvironmentId.SPACE,
    /** 0..1: separação entre os olhos no modo VR Box (sensação de profundidade das janelas). */
    val stereoDepth: Float = 0.5f,
    val controllerEnabled: Boolean = true,
) {
    /** No modo VR Box o fundo é um ambiente virtual; a imagem da câmera só é exibida no modo Normal. */
    val showCameraPreview: Boolean get() = cameraBackground && viewMode == ViewMode.NORMAL

    /** A câmera só é aberta (e a permissão só pedida) se algo a usa. */
    val cameraNeeded: Boolean get() = showCameraPreview || handTrackingEnabled

    companion object {
        val ALLOWED_FPS = listOf(10, 15, 20, 30)
    }
}

/** Serialização tolerante: valor ausente/inválido volta ao padrão; números são limitados à faixa válida. */
object SettingsCodec {
    fun encode(s: NexusSettings): Map<String, String> = mapOf(
        "graphicsQuality" to s.graphicsQuality.name,
        "analysisResolution" to s.analysisResolution.name,
        "analysisFps" to s.analysisFps.toString(),
        "handTrackingEnabled" to s.handTrackingEnabled.toString(),
        "gestureSensitivity" to s.gestureSensitivity.toString(),
        "showHandSkeleton" to s.showHandSkeleton.toString(),
        "cameraBackground" to s.cameraBackground.toString(),
        "orientation" to s.orientation.name,
        "showDiagnostics" to s.showDiagnostics.toString(),
        "viewMode" to s.viewMode.name,
        "environment" to s.environment.name,
        "stereoDepth" to s.stereoDepth.toString(),
        "controllerEnabled" to s.controllerEnabled.toString(),
    )

    fun decode(m: Map<String, String>): NexusSettings {
        val d = NexusSettings()
        return NexusSettings(
            graphicsQuality = enumOr(m["graphicsQuality"], d.graphicsQuality),
            analysisResolution = enumOr(m["analysisResolution"], d.analysisResolution),
            analysisFps = nearestFps(m["analysisFps"]?.toIntOrNull(), d.analysisFps),
            handTrackingEnabled = m["handTrackingEnabled"]?.toBooleanStrictOrNull() ?: d.handTrackingEnabled,
            gestureSensitivity = (m["gestureSensitivity"]?.toFloatOrNull() ?: d.gestureSensitivity)
                .let { if (it.isNaN()) d.gestureSensitivity else it.coerceIn(0f, 1f) },
            showHandSkeleton = m["showHandSkeleton"]?.toBooleanStrictOrNull() ?: d.showHandSkeleton,
            cameraBackground = m["cameraBackground"]?.toBooleanStrictOrNull() ?: d.cameraBackground,
            orientation = enumOr(m["orientation"], d.orientation),
            showDiagnostics = m["showDiagnostics"]?.toBooleanStrictOrNull() ?: d.showDiagnostics,
            viewMode = enumOr(m["viewMode"], d.viewMode),
            environment = enumOr(m["environment"], d.environment),
            stereoDepth = (m["stereoDepth"]?.toFloatOrNull() ?: d.stereoDepth)
                .let { if (it.isNaN()) d.stereoDepth else it.coerceIn(0f, 1f) },
            controllerEnabled = m["controllerEnabled"]?.toBooleanStrictOrNull() ?: d.controllerEnabled,
        )
    }

    private inline fun <reified E : Enum<E>> enumOr(raw: String?, default: E): E =
        raw?.let { r -> enumValues<E>().firstOrNull { it.name == r } } ?: default

    private fun nearestFps(v: Int?, default: Int): Int =
        if (v == null) default else NexusSettings.ALLOWED_FPS.minByOrNull { kotlin.math.abs(it - v) } ?: default
}
