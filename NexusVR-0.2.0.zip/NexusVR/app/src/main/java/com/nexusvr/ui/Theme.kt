package com.nexusvr.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.background
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

object Nx {
    val bg = Color(0xFF070B14)
    val panel = Color(0xFF0E1626)
    val panelHi = Color(0xFF152238)
    val line = Color(0x33FFFFFF)
    val cyan = Color(0xFF3DE8FF)
    val violet = Color(0xFF7C5CFF)
    val text = Color(0xFFE6F1FF)
    val dim = Color(0xFF8FA3BF)
    val ok = Color(0xFF3DDC97)
    val warn = Color(0xFFFFC857)
    val bad = Color(0xFFFF5C7A)
}

@Composable
fun NexusTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Nx.cyan, onPrimary = Color(0xFF07101C),
            secondary = Nx.violet, background = Nx.bg, surface = Nx.panel,
            onSurface = Nx.text, onBackground = Nx.text,
        ),
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0xFF0B1426), Nx.bg))),
        ) { content() }
    }
}
