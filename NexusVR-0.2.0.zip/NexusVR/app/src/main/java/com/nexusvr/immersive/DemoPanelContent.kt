package com.nexusvr.immersive

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import com.nexusvr.core.Box

/**
 * Janela de demonstração: chave, botão com contador e lista rolável.
 * Serve para validar seleção, rolagem e feedback — sem exibir mensagem a cada gesto.
 */
class DemoPanelContent : WindowContent {
    private var toggleOn = true
    private var count = 0
    private var scroll = 0f

    private val items = List(30) { "Item de exemplo ${it + 1}" }

    // Retângulos em coordenadas LOCAIS ao corpo; recalculados a cada desenho.
    private val toggleRect = RectF()
    private val buttonRect = RectF()
    private var listTop = 0f
    private var listH = 0f
    private var lineH = 0f
    private var lastBodyW = 0f
    private var lastBodyH = 0f
    private var lastDensity = 1f

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    private fun layout(w: Float, h: Float, d: Float) {
        lastBodyW = w; lastBodyH = h; lastDensity = d
        val pad = 16f * d
        toggleRect.set(pad, pad, w - pad, pad + 48f * d)
        buttonRect.set(pad, toggleRect.bottom + 12f * d, w - pad, toggleRect.bottom + 12f * d + 52f * d)
        listTop = buttonRect.bottom + 14f * d
        listH = (h - listTop - pad).coerceAtLeast(0f)
        lineH = 34f * d
    }

    private fun maxScroll() = (items.size * lineH - listH).coerceAtLeast(0f)

    override fun draw(canvas: Canvas, body: Box, style: SpatialStyle) {
        val d = style.density
        layout(body.w, body.h, d)
        val ox = body.x
        val oy = body.y

        // Chave
        rect.set(ox + toggleRect.left, oy + toggleRect.top, ox + toggleRect.right, oy + toggleRect.bottom)
        canvas.drawRoundRect(rect, 10f * d, 10f * d, p.fill(0xFF121E33.toInt()))
        p.fill(style.text).textSize = style.sp(15f)
        p.typeface = Typeface.DEFAULT
        canvas.drawText("Brilho suave", rect.left + 14f * d, rect.centerY() + 5f * d, p)
        val trackW = 52f * d
        val trackH = 26f * d
        val tr = RectF(rect.right - trackW - 14f * d, rect.centerY() - trackH / 2, rect.right - 14f * d, rect.centerY() + trackH / 2)
        canvas.drawRoundRect(tr, trackH / 2, trackH / 2, p.fill(if (toggleOn) style.accent else 0xFF3A4A63.toInt()))
        val knobR = trackH / 2 - 3f * d
        val knobX = if (toggleOn) tr.right - trackH / 2 else tr.left + trackH / 2
        canvas.drawCircle(knobX, tr.centerY(), knobR, p.fill(0xFFFFFFFF.toInt()))

        // Botão
        rect.set(ox + buttonRect.left, oy + buttonRect.top, ox + buttonRect.right, oy + buttonRect.bottom)
        canvas.drawRoundRect(rect, 12f * d, 12f * d, p.fill(style.accent2))
        p.fill(0xFFFFFFFF.toInt()).textSize = style.sp(16f)
        p.typeface = Typeface.DEFAULT_BOLD
        p.textAlign = Paint.Align.CENTER
        canvas.drawText("Selecionar  •  $count", rect.centerX(), rect.centerY() + 6f * d, p)
        p.textAlign = Paint.Align.LEFT

        // Lista rolável (recortada à sua área)
        if (listH > 0f) {
            val save = canvas.save()
            canvas.clipRect(ox + toggleRect.left, oy + listTop, ox + toggleRect.right, oy + listTop + listH)
            p.typeface = Typeface.DEFAULT
            p.textSize = style.sp(14f)
            val first = (scroll / lineH).toInt().coerceAtLeast(0)
            val last = ((scroll + listH) / lineH).toInt().coerceAtMost(items.size - 1)
            for (i in first..last) {
                val y = oy + listTop + i * lineH - scroll
                p.fill(if (i % 2 == 0) style.text else style.textDim)
                canvas.drawText(items[i], ox + toggleRect.left + 6f * d, y + lineH * 0.66f, p)
            }
            canvas.restoreToCount(save)
            // Indicador de rolagem discreto
            val max = maxScroll()
            if (max > 0f) {
                val trackTop = oy + listTop
                val thumbH = (listH * listH / (items.size * lineH)).coerceAtLeast(24f * d)
                val thumbY = trackTop + (listH - thumbH) * (scroll / max)
                rect.set(ox + toggleRect.right - 4f * d, thumbY, ox + toggleRect.right, thumbY + thumbH)
                canvas.drawRoundRect(rect, 2f * d, 2f * d, p.fill(0x663DE8FF))
            }
        }
    }

    override fun onTap(localX: Float, localY: Float) {
        if (toggleRect.contains(localX, localY)) {
            toggleOn = !toggleOn
        } else if (buttonRect.contains(localX, localY)) {
            count++
        }
    }

    override fun onScroll(dy: Float) {
        scroll = (scroll - dy).coerceIn(0f, maxScroll())
    }
}
