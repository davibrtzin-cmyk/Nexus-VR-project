package com.nexusvr.core

import kotlin.math.max

data class Vec2(val x: Float, val y: Float)

/** Retângulo em pixels da view. (Não usa android.graphics para permitir testes na JVM.) */
data class Box(val x: Float, val y: Float, val w: Float, val h: Float) {
    val right: Float get() = x + w
    val bottom: Float get() = y + h
    fun contains(px: Float, py: Float): Boolean = px >= x && px <= right && py >= y && py <= bottom
}

/**
 * Converte coordenadas normalizadas (0..1) de uma imagem "em pé" (já rotacionada) para pixels
 * de uma view que a exibe com escala FILL_CENTER (como PreviewView.ScaleType.FILL_CENTER).
 * Vale apenas se o Preview e a análise cobrem o mesmo campo de visão (ambos 4:3 aqui).
 */
class FillCenterMapper(
    private val imageW: Int,
    private val imageH: Int,
    viewW: Float,
    viewH: Float,
    private val mirrorX: Boolean = false,
) {
    private val scale: Float = max(viewW / imageW, viewH / imageH)
    private val offX: Float = (viewW - imageW * scale) / 2f
    private val offY: Float = (viewH - imageH * scale) / 2f

    fun map(nx: Float, ny: Float): Vec2 {
        val ux = if (mirrorX) 1f - nx else nx
        return Vec2(ux * imageW * scale + offX, ny * imageH * scale + offY)
    }
}
