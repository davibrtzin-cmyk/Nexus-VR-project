package com.nexusvr.platform

import android.content.Context
import com.nexusvr.core.settings.NexusSettings
import com.nexusvr.core.settings.SettingsCodec

/** Persistência local das preferências (SharedPreferences). Nada sai do aparelho. */
class SettingsRepository(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("nexus_settings", Context.MODE_PRIVATE)

    fun load(): NexusSettings {
        val raw = HashMap<String, String>()
        for ((k, v) in prefs.all) if (v is String) raw[k] = v
        return SettingsCodec.decode(raw)
    }

    fun save(settings: NexusSettings) {
        val editor = prefs.edit()
        for ((k, v) in SettingsCodec.encode(settings)) editor.putString(k, v)
        editor.apply()
    }

    fun reset(): NexusSettings {
        prefs.edit().clear().apply()
        return NexusSettings()
    }
}
