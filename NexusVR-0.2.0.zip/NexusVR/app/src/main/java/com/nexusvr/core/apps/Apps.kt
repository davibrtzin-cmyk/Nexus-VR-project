package com.nexusvr.core.apps

enum class AppStatus(val label: String) {
    AVAILABLE("Pronto"),
    EXPERIMENTAL("Experimental"),
    IN_DEVELOPMENT("Em desenvolvimento"),
}

/**
 * Aplicativos (tipos de janela) do NEXUS VR. É só catálogo: o desenho de cada um fica em
 * immersive/apps. Os marcados IN_DEVELOPMENT NÃO podem ser abertos (não há botão falso).
 */
enum class AppId(val label: String, val description: String, val status: AppStatus) {
    DEMO("Painel de demonstração", "Botão, chave e lista rolável para testar a interação.", AppStatus.AVAILABLE),
    CLOCK("Relógio", "Hora, data, tempo de sessão e cronômetro.", AppStatus.AVAILABLE),
    GALLERY("Galeria", "Suas fotos, escolhidas pelo seletor do Android (sem permissão de armazenamento).", AppStatus.EXPERIMENTAL),
    HELP("Ajuda", "Gestos, controles e limitações.", AppStatus.AVAILABLE),
    TOOLS("Ferramentas", "Modo VR Box, ambiente, profundidade, esqueleto e diagnóstico em tempo real.", AppStatus.AVAILABLE),
    BROWSER("Navegador", "Páginas web reais em janela virtual.", AppStatus.IN_DEVELOPMENT),
    VIDEO("Vídeo", "Reprodutor de vídeos locais.", AppStatus.IN_DEVELOPMENT);

    val launchable: Boolean get() = status != AppStatus.IN_DEVELOPMENT
}

object AppCatalog {
    val launchable: List<AppId> = AppId.entries.filter { it.launchable }
    val planned: List<AppId> = AppId.entries.filter { !it.launchable }
}
