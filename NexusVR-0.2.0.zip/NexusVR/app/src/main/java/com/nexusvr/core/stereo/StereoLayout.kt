package com.nexusvr.core.stereo

import com.nexusvr.core.Vec2

/**
 * Geometria do modo VR Box: a tela é dividida em dois "olhos" lado a lado e a mesma cena lógica é
 * desenhada nos dois, com um pequeno deslocamento horizontal oposto (paralaxe) que dá sensação de
 * profundidade às janelas. Lógica pura, testável na JVM.
 *
 * Coordenadas LÓGICAS são as da cena (janelas, cursor): largura [logicalW] x [viewH].
 * Coordenadas de TELA são as da View inteira.
 *
 * Limitações assumidas: não há correção de distorção das lentes do VR Box nem ajuste de IPD por
 * aparelho; a profundidade é só paralaxe horizontal.
 */
class StereoLayout(
    val viewW: Float,
    val viewH: Float,
    val stereo: Boolean,
    depth: Float,
    maxShiftPx: Float,
) {
    val logicalW: Float = if (stereo) viewW / 2f else viewW
    val eyes: Int get() = if (stereo) 2 else 1

    private val shift: Float = if (stereo) depth.coerceIn(0f, 1f) * maxShiftPx else 0f

    /** Borda esquerda (em tela) do olho [eye] (0 = esquerdo, 1 = direito). */
    fun eyeLeft(eye: Int): Float = if (stereo && eye == 1) viewW / 2f else 0f

    /** Deslocamento da camada das janelas: objeto "à frente" => olho esquerdo para a direita, direito para a esquerda. */
    fun windowShift(eye: Int): Float = if (!stereo) 0f else if (eye == 0) shift else -shift

    /** O fundo fica "mais longe": desloca-se menos e no sentido oposto ao das janelas. */
    fun environmentShift(eye: Int): Float = -windowShift(eye) * 0.5f

    /** Converte um ponto da tela (ex.: toque) para coordenadas lógicas. */
    fun toLogical(x: Float, y: Float): Vec2 {
        if (!stereo) return Vec2(x, y)
        val eye = if (x < viewW / 2f) 0 else 1
        return Vec2(x - eyeLeft(eye) - windowShift(eye), y)
    }

    /** Converte um ponto lógico para a tela, no olho [eye]. */
    fun toScreen(lx: Float, ly: Float, eye: Int): Vec2 = Vec2(lx + eyeLeft(eye) + windowShift(eye), ly)
}
