package com.nexusvr.core.input

/** Origem de um evento. A mesma lógica de interface atende mão, toque e (futuramente) controles. */
enum class InputSource { HAND, TOUCH, KEY }

/**
 * Eventos de ponteiro em pixels da view. É o contrato entre "reconhecimento" e "interface":
 * o motor de gestos produz estes eventos; o sistema de janelas só os consome.
 */
sealed interface PointerEvent {
    val x: Float
    val y: Float
    val source: InputSource
}

data class PointerMove(override val x: Float, override val y: Float, override val source: InputSource) : PointerEvent
data class PointerDown(override val x: Float, override val y: Float, override val source: InputSource) : PointerEvent
data class PointerUp(override val x: Float, override val y: Float, override val source: InputSource) : PointerEvent

/** Interação interrompida (ex.: mão perdida durante uma pinça). Não conta como clique. */
data class PointerCancel(override val x: Float, override val y: Float, override val source: InputSource) : PointerEvent

/** O ponteiro deixou de existir (mão saiu do campo). Serve para esconder o cursor. */
data class PointerExit(override val x: Float, override val y: Float, override val source: InputSource) : PointerEvent
