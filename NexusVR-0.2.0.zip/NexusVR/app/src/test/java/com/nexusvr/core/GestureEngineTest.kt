package com.nexusvr.core

import com.nexusvr.core.gesture.GestureConfig
import com.nexusvr.core.gesture.GestureEngine
import com.nexusvr.core.gesture.Lm
import com.nexusvr.core.input.PointerCancel
import com.nexusvr.core.input.PointerDown
import com.nexusvr.core.input.PointerEvent
import com.nexusvr.core.input.PointerExit
import com.nexusvr.core.input.PointerMove
import com.nexusvr.core.input.PointerUp
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GestureEngineTest {

    /** Mão sintética: pulso em (0.5,0.8), base do médio em (0.5,0.5) => tamanho da mão = 0.3.
     *  [gap] é a distância polegar–indicador em múltiplos do tamanho da mão. */
    private fun hand(gap: Float, cx: Float = 0.5f, cy: Float = 0.4f): FloatArray {
        val a = FloatArray(Lm.COUNT * 3)
        fun set(i: Int, x: Float, y: Float) { a[i * 3] = x; a[i * 3 + 1] = y }
        set(Lm.WRIST, 0.5f, 0.8f)
        set(Lm.MIDDLE_MCP, 0.5f, 0.5f)
        val half = gap * 0.3f / 2f
        set(Lm.THUMB_TIP, cx - half, cy)
        set(Lm.INDEX_TIP, cx + half, cy)
        return a
    }

    private val open = 1.0f      // dedos afastados
    private val closed = 0.08f   // pinça

    private fun engine() = GestureEngine(GestureConfig(), { x, y -> Vec2(x * 1000f, y * 1000f) })

    private inline fun <reified T : PointerEvent> List<PointerEvent>.count() = filterIsInstance<T>().size

    /** Alimenta quadros a cada 66 ms (~15 fps) e junta todos os eventos. */
    private fun feed(e: GestureEngine, t0: Long, vararg frames: FloatArray?): Pair<List<PointerEvent>, Long> {
        val all = ArrayList<PointerEvent>()
        var t = t0
        for (f in frames) { all += e.onFrame(f, t); t += 66 }
        return all to t
    }

    @Test fun `mao aberta nao gera clique`() {
        val (ev, _) = feed(engine(), 0, hand(open), hand(open), hand(open))
        assertEquals(0, ev.count<PointerDown>())
        assertEquals(3, ev.count<PointerMove>())
    }

    @Test fun `pinca valida gera exatamente um Down e um Up`() {
        val (ev, _) = feed(engine(), 0, hand(open), hand(closed), hand(closed), hand(closed), hand(open), hand(open))
        assertEquals(1, ev.count<PointerDown>())
        assertEquals(1, ev.count<PointerUp>())
        assertTrue(ev.indexOfFirst { it is PointerDown } < ev.indexOfFirst { it is PointerUp })
    }

    @Test fun `um unico quadro ruidoso nao dispara pinca`() {
        val (ev, _) = feed(engine(), 0, hand(open), hand(closed), hand(open), hand(open))
        assertEquals(0, ev.count<PointerDown>())
    }

    @Test fun `histerese - distancia intermediaria mantem a pinca`() {
        // Sensibilidade 0.5: fecha abaixo de 0.31 e só abre acima de 0.31*1.35 ≈ 0.42.
        // 0.38 está entre os dois: a pinça já iniciada deve ser mantida.
        val (ev, _) = feed(engine(), 0, hand(closed), hand(closed), hand(0.38f), hand(0.38f), hand(0.38f))
        assertEquals(1, ev.count<PointerDown>())
        assertEquals(0, ev.count<PointerUp>())
        // e acima do limiar de abrir (0.45) a pinça é solta
        val (ev2, _) = feed(engine(), 0, hand(closed), hand(closed), hand(0.45f), hand(0.45f))
        assertEquals(1, ev2.count<PointerUp>())
    }

    @Test fun `debounce impede clique duplicado logo apos soltar`() {
        val e = engine()
        // pinça, solta, pinça de novo dentro de 150 ms depois do Up
        val a = ArrayList<PointerEvent>()
        a += e.onFrame(hand(closed), 0); a += e.onFrame(hand(closed), 20)       // Down em t=20
        a += e.onFrame(hand(open), 40); a += e.onFrame(hand(open), 60)          // Up em t=60
        a += e.onFrame(hand(closed), 80); a += e.onFrame(hand(closed), 100)     // dentro do debounce
        assertEquals(1, a.count<PointerDown>())
        a += e.onFrame(hand(closed), 300)                                        // passou do debounce
        assertEquals(2, a.count<PointerDown>())
    }

    @Test fun `ausencia de mao nao gera eventos`() {
        val (ev, _) = feed(engine(), 0, null, null, null)
        assertTrue(ev.isEmpty())
    }

    @Test fun `mao perdida durante a pinca cancela sem Up e esconde o cursor`() {
        val e = engine()
        val ev = ArrayList<PointerEvent>()
        ev += e.onFrame(hand(closed), 0); ev += e.onFrame(hand(closed), 66)   // Down
        ev += e.onFrame(null, 200)                                              // < 300 ms: ainda tolera
        assertEquals(0, ev.count<PointerCancel>())
        ev += e.onFrame(null, 500)                                              // > 300 ms desde a última detecção
        assertEquals(1, ev.count<PointerCancel>())
        assertEquals(1, ev.count<PointerExit>())
        assertEquals(0, ev.count<PointerUp>())
    }

    @Test fun `cursor segue a posicao da mao no mapeamento`() {
        val e = engine()
        val ev = e.onFrame(hand(open, cx = 0.25f, cy = 0.4f), 0)
        val m = ev.filterIsInstance<PointerMove>().single()
        assertEquals(250f, m.x, 1f)
        assertEquals(400f, m.y, 1f)
    }

    @Test fun `sensibilidade alta aceita pinca mais aberta`() {
        val gap = 0.38f
        val low = GestureEngine(GestureConfig(sensitivity = 0f))
        val high = GestureEngine(GestureConfig(sensitivity = 1f))
        val l = ArrayList<PointerEvent>(); val h = ArrayList<PointerEvent>()
        for (t in listOf(0L, 66L, 132L)) { l += low.onFrame(hand(gap), t); h += high.onFrame(hand(gap), t) }
        assertEquals(0, l.count<PointerDown>())
        assertEquals(1, h.count<PointerDown>())
    }

    @Test fun `landmarks incompletos sao tratados como ausencia`() {
        val e = engine()
        assertTrue(e.onFrame(FloatArray(10), 0).isEmpty())
    }
}
