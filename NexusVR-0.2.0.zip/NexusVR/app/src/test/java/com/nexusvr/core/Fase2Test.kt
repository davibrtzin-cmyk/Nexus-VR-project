package com.nexusvr.core

import com.nexusvr.core.apps.AppCatalog
import com.nexusvr.core.apps.AppId
import com.nexusvr.core.environment.StarField
import com.nexusvr.core.experience.LocalExperienceRegistry
import com.nexusvr.core.experience.ManifestValidator
import com.nexusvr.core.input.ControllerCursor
import com.nexusvr.core.input.InputSource
import com.nexusvr.core.input.PointerCancel
import com.nexusvr.core.input.PointerDown
import com.nexusvr.core.input.PointerMove
import com.nexusvr.core.input.PointerUp
import com.nexusvr.core.settings.EnvironmentId
import com.nexusvr.core.settings.NexusSettings
import com.nexusvr.core.settings.SettingsCodec
import com.nexusvr.core.settings.ViewMode
import com.nexusvr.core.stereo.StereoLayout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class Fase2Test {

    // ---- estéreo ----
    @Test fun `modo normal nao altera coordenadas`() {
        val l = StereoLayout(1600f, 720f, false, 1f, 30f)
        assertEquals(1600f, l.logicalW, 0f)
        assertEquals(1, l.eyes)
        val p = l.toLogical(123f, 45f)
        assertEquals(123f, p.x, 0f); assertEquals(45f, p.y, 0f)
    }

    @Test fun `estereo divide a largura e converte ida e volta nos dois olhos`() {
        val l = StereoLayout(1600f, 720f, true, 0.5f, 30f)
        assertEquals(800f, l.logicalW, 0f)
        assertEquals(2, l.eyes)
        // só pontos visíveis: perto da borda do olho o deslocamento os empurra para fora do recorte
        for (eye in 0..1) for (lx in listOf(100f, 400f, 700f)) {
            val s = l.toScreen(lx, 50f, eye)
            val back = l.toLogical(s.x, s.y)
            assertEquals("olho $eye x=$lx", lx, back.x, 0.01f)
        }
    }

    @Test fun `paralaxe e simetrica e o fundo anda menos e no sentido oposto`() {
        val l = StereoLayout(1600f, 720f, true, 1f, 30f)
        assertEquals(30f, l.windowShift(0), 0f)
        assertEquals(-30f, l.windowShift(1), 0f)
        assertEquals(-15f, l.environmentShift(0), 0f)
        assertEquals(15f, l.environmentShift(1), 0f)
        assertEquals(0f, StereoLayout(1600f, 720f, true, 0f, 30f).windowShift(0), 0f)
        assertEquals(30f, StereoLayout(1600f, 720f, true, 9f, 30f).windowShift(0), 0f) // profundidade limitada a 1
    }

    // ---- controle Bluetooth ----
    @Test fun `zona morta nao move nem gera eventos`() {
        val c = ControllerCursor(); c.setBounds(800f, 400f)
        c.setAxes(0.1f, -0.15f)
        assertFalse(c.isActive)
        assertTrue(c.update(16).isEmpty())
    }

    @Test fun `analogico move o cursor com limite na borda`() {
        val c = ControllerCursor(speedPxPerSec = 1000f); c.setBounds(800f, 400f)
        assertEquals(400f, c.x, 0f)
        c.setAxes(1f, 0f)
        val ev = c.update(40)
        assertTrue(ev.single() is PointerMove)
        assertEquals(440f, c.x, 0.01f)
        repeat(100) { c.update(50) }
        assertEquals(800f, c.x, 0f)
        assertEquals(200f, c.y, 0f)
        assertTrue(c.update(50).isEmpty())   // na borda: sem evento
    }

    @Test fun `direcional diagonal nao e mais rapido que o analogico`() {
        val c = ControllerCursor(speedPxPerSec = 1000f); c.setBounds(800f, 800f)
        c.setDpad(1, 1)
        c.update(50)
        val d = Math.hypot((c.x - 400f).toDouble(), (c.y - 400f).toDouble())
        assertEquals(50.0, d, 0.5)
    }

    @Test fun `botao gera um Down e um Up e ignora repeticao`() {
        val c = ControllerCursor(); c.setBounds(800f, 400f)
        val down = c.onButton(true)
        assertTrue(down.last() is PointerDown)
        assertTrue(down.all { it.source == InputSource.KEY })
        assertTrue(c.onButton(true).isEmpty())          // auto-repeat do teclado
        assertTrue(c.onButton(false).single() is PointerUp)
        assertTrue(c.onButton(false).isEmpty())
    }

    @Test fun `perder o controle durante a pressao cancela`() {
        val c = ControllerCursor(); c.setBounds(800f, 400f)
        c.onButton(true); c.setDpad(1, 0)
        assertTrue(c.release().single() is PointerCancel)
        assertFalse(c.isActive)
        assertTrue(c.release().isEmpty())
    }

    // ---- ambientes ----
    @Test fun `estrelas sao deterministicas e ficam em 0 a 1`() {
        val a = StarField.generate(42L, 200)
        assertEquals(600, a.size)
        assertTrue(a.contentEquals(StarField.generate(42L, 200)))
        assertFalse(a.contentEquals(StarField.generate(43L, 200)))
        assertTrue(a.all { it in 0f..1f })
        assertEquals(0, StarField.generate(1L, -5).size)
    }

    @Test fun `ambientes ciclam por todos e voltam ao inicio`() {
        var e = EnvironmentId.SPACE
        val seen = HashSet<EnvironmentId>()
        repeat(EnvironmentId.entries.size) { seen += e; e = e.next() }
        assertEquals(EnvironmentId.entries.size, seen.size)
        assertEquals(EnvironmentId.SPACE, e)
    }

    // ---- configurações novas ----
    @Test fun `novas configuracoes sobrevivem a ida e volta e ao lixo`() {
        val s = NexusSettings(viewMode = ViewMode.STEREO, environment = EnvironmentId.AURORA, stereoDepth = 0.8f, controllerEnabled = false)
        assertEquals(s, SettingsCodec.decode(SettingsCodec.encode(s)))
        val bad = SettingsCodec.decode(mapOf("viewMode" to "3D", "environment" to "x", "stereoDepth" to "NaN", "controllerEnabled" to "?"))
        assertEquals(NexusSettings(), bad)
        assertEquals(1f, SettingsCodec.decode(mapOf("stereoDepth" to "9")).stereoDepth, 0f)
    }

    @Test fun `no modo VR Box a camera so e necessaria para as maos`() {
        val s = NexusSettings(viewMode = ViewMode.STEREO, cameraBackground = true, handTrackingEnabled = false)
        assertFalse(s.showCameraPreview)
        assertFalse(s.cameraNeeded)
        assertTrue(s.copy(handTrackingEnabled = true).cameraNeeded)
        assertTrue(NexusSettings(viewMode = ViewMode.NORMAL).showCameraPreview)
    }

    // ---- apps e biblioteca ----
    @Test fun `catalogo separa abriveis de planejados`() {
        assertTrue(AppId.BROWSER in AppCatalog.planned && AppId.VIDEO in AppCatalog.planned)
        assertTrue(AppCatalog.launchable.all { it.launchable })
        assertEquals(AppId.entries.size, AppCatalog.launchable.size + AppCatalog.planned.size)
        assertEquals(AppId.entries.size, AppId.entries.map { it.label }.toSet().size)
    }

    @Test fun `todas as experiencias da biblioteca sao validas e unicas`() {
        val all = LocalExperienceRegistry.all
        assertTrue(all.size >= 3)
        assertEquals(all.size, all.map { it.id }.toSet().size)
        all.forEach { assertTrue("${it.id}: ${ManifestValidator.validate(it)}", ManifestValidator.validate(it).isEmpty()) }
        assertEquals(ViewMode.STEREO, LocalExperienceRegistry.find(LocalExperienceRegistry.VR_SPACE_ID)!!.viewMode)
    }

    @Test fun `validador rejeita app em desenvolvimento como inicial`() {
        val bad = LocalExperienceRegistry.all.first().copy(initialApps = listOf(AppId.BROWSER))
        assertEquals(1, ManifestValidator.validate(bad).size)
        assertEquals(1, ManifestValidator.validate(bad.copy(initialApps = emptyList())).size)
    }
}
