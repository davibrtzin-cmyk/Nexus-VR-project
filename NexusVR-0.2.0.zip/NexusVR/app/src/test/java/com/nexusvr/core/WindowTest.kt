package com.nexusvr.core

import com.nexusvr.core.input.InputSource.TOUCH
import com.nexusvr.core.input.PointerCancel
import com.nexusvr.core.input.PointerDown
import com.nexusvr.core.input.PointerExit
import com.nexusvr.core.input.PointerMove
import com.nexusvr.core.input.PointerUp
import com.nexusvr.core.window.Hit
import com.nexusvr.core.window.HudButton
import com.nexusvr.core.window.InteractionListener
import com.nexusvr.core.window.Part
import com.nexusvr.core.window.VirtualWindow
import com.nexusvr.core.window.WindowInteractor
import com.nexusvr.core.window.WindowManager
import com.nexusvr.core.window.WindowMetrics
import com.nexusvr.core.window.WindowState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class WindowTest {

    private val metrics = WindowMetrics(
        titleH = 50f, button = 40f, handle = 36f, dockH = 40f, dockItemW = 140f,
        margin = 10f, minW = 200f, minH = 150f,
    )

    private fun manager(): WindowManager = WindowManager(metrics).also { it.setBounds(1000f, 600f) }

    // --- WindowManager ---

    @Test fun `abrir limita a janela a area visivel`() {
        val wm = manager()
        val w = wm.open("demo", "A", Box(900f, 500f, 400f, 300f))
        assertTrue(w.box.right <= 1000f && w.box.bottom <= 600f && w.box.x >= 0f && w.box.y >= 0f)
    }

    @Test fun `abrir antes do layout nao zera a janela`() {
        val wm = WindowManager(metrics)
        val w = wm.open("demo", "A", Box(10f, 10f, 300f, 200f))
        assertEquals(300f, w.box.w, 0f)
        wm.setBounds(1000f, 600f)
        assertEquals(300f, wm.get(w.id)!!.box.w, 0f)
    }

    @Test fun `focar traz para frente e hit-test respeita a ordem`() {
        val wm = manager()
        val a = wm.open("demo", "A", Box(100f, 100f, 400f, 300f))
        val b = wm.open("demo", "B", Box(200f, 150f, 400f, 300f))   // sobrepõe A, está na frente
        assertEquals(b.id, wm.hitTest(300f, 300f).windowId)
        wm.focus(a.id)
        assertEquals(a.id, wm.hitTest(300f, 300f).windowId)
        assertEquals(a.id, wm.focusedId)
    }

    @Test fun `partes da janela sao identificadas`() {
        val wm = manager()
        val w = wm.open("demo", "A", Box(100f, 100f, 400f, 300f))
        val close = wm.closeBox(w)
        val min = wm.minimizeBox(w)
        val rs = wm.resizeBox(w)
        assertEquals(Part.CLOSE, wm.hitTest(close.x + 5, close.y + 5).part)
        assertEquals(Part.MINIMIZE, wm.hitTest(min.x + 5, min.y + 5).part)
        assertEquals(Part.TITLE, wm.hitTest(120f, 110f).part)
        assertEquals(Part.RESIZE, wm.hitTest(rs.x + 5, rs.y + 5).part)
        assertEquals(Part.BODY, wm.hitTest(300f, 250f).part)
        assertEquals(Hit.NONE, wm.hitTest(5f, 5f))
    }

    @Test fun `minimizar tira do hit-test e vai para o dock, restaurar volta`() {
        val wm = manager()
        val w = wm.open("demo", "A", Box(100f, 100f, 400f, 300f))
        wm.minimize(w.id)
        assertEquals(Hit.NONE, wm.hitTest(300f, 250f))
        val dock = wm.dockBox(0)
        assertEquals(Hit(w.id, Part.DOCK), wm.hitTest(dock.x + 5, dock.y + 5))
        wm.restore(w.id)
        assertEquals(WindowState.NORMAL, wm.get(w.id)!!.state)
        assertEquals(w.id, wm.hitTest(300f, 250f).windowId)
    }

    @Test fun `mover e redimensionar respeitam limites`() {
        val wm = manager()
        val w = wm.open("demo", "A", Box(100f, 100f, 400f, 300f))
        wm.moveTo(w.id, -50f, 9999f)
        assertEquals(0f, w.box.x, 0f)
        assertEquals(600f - 300f, w.box.y, 0f)
        wm.moveTo(w.id, 100f, 100f)
        wm.resizeTo(w.id, 10f, 10f)
        assertEquals(200f, w.box.w, 0f); assertEquals(150f, w.box.h, 0f)
        wm.resizeTo(w.id, 5000f, 5000f)
        assertEquals(1000f - 100f, w.box.w, 0f); assertEquals(600f - 100f, w.box.h, 0f)
    }

    @Test fun `fechar remove e avisa`() {
        val wm = manager()
        var closed = -1
        wm.onClosed = { closed = it }
        val w = wm.open("demo", "A", Box(100f, 100f, 400f, 300f))
        assertTrue(wm.close(w.id))
        assertEquals(w.id, closed)
        assertFalse(wm.close(w.id))
        assertTrue(wm.windows.isEmpty())
    }

    @Test fun `mudar o tamanho da area reescala as janelas`() {
        val wm = manager()
        val w = wm.open("demo", "A", Box(100f, 100f, 400f, 300f))
        wm.setBounds(2000f, 1200f)
        assertEquals(200f, w.box.x, 0.01f)
        assertEquals(800f, w.box.w, 0.01f)
    }

    // --- WindowInteractor ---

    private class Rec : InteractionListener {
        val taps = ArrayList<Triple<Int, Float, Float>>()
        var scroll = 0f
        val hud = ArrayList<String>()
        override fun onBodyTap(window: VirtualWindow, localX: Float, localY: Float) { taps += Triple(window.id, localX, localY) }
        override fun onBodyScroll(window: VirtualWindow, dy: Float) { scroll += dy }
        override fun onHudButton(id: String) { hud += id }
    }

    private class Rig {
        val wm = WindowManager(WindowMetrics(50f, 40f, 36f, 40f, 140f, 10f, 200f, 150f)).also { it.setBounds(1000f, 600f) }
        val rec = Rec()
        val it = WindowInteractor(wm, slopPx = 20f).also { i -> i.listener = rec }
        val win = wm.open("demo", "A", Box(100f, 100f, 400f, 300f))
        fun move(x: Float, y: Float) = it.onEvent(PointerMove(x, y, TOUCH))
        fun down(x: Float, y: Float) { move(x, y); it.onEvent(PointerDown(x, y, TOUCH)) }
        fun up(x: Float, y: Float) = it.onEvent(PointerUp(x, y, TOUCH))
    }

    @Test fun `toque no corpo gera um tap com coordenadas locais`() {
        val r = Rig()
        r.down(300f, 250f); r.up(300f, 250f)
        assertEquals(1, r.rec.taps.size)
        val body = r.wm.bodyBox(r.win)
        assertEquals(300f - body.x, r.rec.taps[0].second, 0.01f)
        assertEquals(250f - body.y, r.rec.taps[0].third, 0.01f)
    }

    @Test fun `tap so dispara ao soltar sobre o mesmo alvo`() {
        val r = Rig()
        val close = r.wm.closeBox(r.win)
        r.down(close.x + 5, close.y + 5)
        r.move(10f, 10f)                 // saiu do botão
        r.up(10f, 10f)
        assertEquals(1, r.wm.windows.size)   // não fechou
    }

    @Test fun `botao fechar fecha e minimizar minimiza`() {
        val r = Rig()
        val min = r.wm.minimizeBox(r.win)
        r.down(min.x + 5, min.y + 5); r.up(min.x + 5, min.y + 5)
        assertEquals(WindowState.MINIMIZED, r.win.state)
        val dock = r.wm.dockBox(0)
        r.down(dock.x + 5, dock.y + 5); r.up(dock.x + 5, dock.y + 5)
        assertEquals(WindowState.NORMAL, r.win.state)
        val close = r.wm.closeBox(r.win)
        r.down(close.x + 5, close.y + 5); r.up(close.x + 5, close.y + 5)
        assertTrue(r.wm.windows.isEmpty())
    }

    @Test fun `arrastar pela barra de titulo move a janela mantendo o ponto de pega`() {
        val r = Rig()
        r.down(150f, 115f)                 // título, 50px do canto esq. e 15 abaixo do topo
        r.move(350f, 315f)
        r.up(350f, 315f)
        assertEquals(300f, r.win.box.x, 0.01f)
        assertEquals(300f, r.win.box.y, 0.01f)
        assertTrue(r.rec.taps.isEmpty())   // arrastar não é clique
    }

    @Test fun `arrastar a alca redimensiona`() {
        val r = Rig()
        val rs = r.wm.resizeBox(r.win)
        val sx = rs.x + 10; val sy = rs.y + 10
        r.down(sx, sy)
        r.move(sx + 100f, sy + 50f)
        r.up(sx + 100f, sy + 50f)
        assertEquals(500f, r.win.box.w, 0.01f)
        assertEquals(350f, r.win.box.h, 0.01f)
    }

    @Test fun `mover alem da tolerancia no corpo vira rolagem e nao tap`() {
        val r = Rig()
        r.down(300f, 250f)
        r.move(300f, 240f)                 // dentro da tolerância: ainda nada
        assertEquals(0f, r.rec.scroll, 0f)
        r.move(300f, 200f)                 // passou da tolerância
        r.move(300f, 180f)
        r.up(300f, 180f)
        assertEquals(-70f, r.rec.scroll, 0.01f)   // total do ponto inicial até 180
        assertTrue(r.rec.taps.isEmpty())
    }

    @Test fun `botao HUD dispara ao soltar sobre ele`() {
        val r = Rig()
        r.it.hudButtons += HudButton("menu", Box(10f, 10f, 100f, 40f))
        r.down(20f, 20f); r.up(20f, 20f)
        assertEquals(listOf("menu"), r.rec.hud)
    }

    @Test fun `cancelamento e saida limpam estado sem acionar nada`() {
        val r = Rig()
        val close = r.wm.closeBox(r.win)
        r.down(close.x + 5, close.y + 5)
        r.it.onEvent(PointerCancel(close.x, close.y, TOUCH))
        r.up(close.x + 5, close.y + 5)
        assertEquals(1, r.wm.windows.size)
        r.it.onEvent(PointerExit(0f, 0f, TOUCH))
        assertFalse(r.it.cursorVisible)
        assertNull(r.it.hoverHud)
    }

    @Test fun `hover e pressed sao expostos para desenho discreto`() {
        val r = Rig()
        val close = r.wm.closeBox(r.win)
        r.move(close.x + 5, close.y + 5)
        assertEquals(Hit(r.win.id, Part.CLOSE), r.it.hoverHit)
        r.it.onEvent(PointerDown(close.x + 5, close.y + 5, TOUCH))
        assertTrue(r.it.pressed)
        assertEquals(Hit(r.win.id, Part.CLOSE), r.it.pressedHit)
    }
}
