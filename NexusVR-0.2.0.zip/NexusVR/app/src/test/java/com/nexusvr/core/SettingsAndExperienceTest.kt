package com.nexusvr.core

import com.nexusvr.core.experience.Capability
import com.nexusvr.core.experience.Compatibility
import com.nexusvr.core.experience.DeviceCapabilities
import com.nexusvr.core.experience.ExperienceManifest
import com.nexusvr.core.experience.InstallState
import com.nexusvr.core.experience.LocalExperienceRegistry
import com.nexusvr.core.experience.ManifestValidator
import com.nexusvr.core.experience.checkCompatibility
import com.nexusvr.core.settings.AnalysisResolution
import com.nexusvr.core.settings.GraphicsQuality
import com.nexusvr.core.settings.NexusSettings
import com.nexusvr.core.settings.OrientationPref
import com.nexusvr.core.settings.SettingsCodec
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SettingsAndExperienceTest {

    @Test fun `configuracoes sobrevivem a ida e volta`() {
        val s = NexusSettings(
            graphicsQuality = GraphicsQuality.LOW,
            analysisResolution = AnalysisResolution.R480,
            analysisFps = 20,
            handTrackingEnabled = false,
            gestureSensitivity = 0.8f,
            showHandSkeleton = true,
            cameraBackground = false,
            orientation = OrientationPref.REVERSE_LANDSCAPE,
            showDiagnostics = true,
        )
        assertEquals(s, SettingsCodec.decode(SettingsCodec.encode(s)))
    }

    @Test fun `armazenamento vazio ou corrompido volta aos padroes`() {
        assertEquals(NexusSettings(), SettingsCodec.decode(emptyMap()))
        val bad = mapOf(
            "graphicsQuality" to "ULTRA", "analysisFps" to "abc", "handTrackingEnabled" to "talvez",
            "gestureSensitivity" to "NaN", "orientation" to "",
        )
        assertEquals(NexusSettings(), SettingsCodec.decode(bad))
    }

    @Test fun `valores numericos sao limitados a faixa valida`() {
        val d = SettingsCodec.decode(mapOf("gestureSensitivity" to "7.5", "analysisFps" to "999"))
        assertEquals(1f, d.gestureSensitivity, 0f)
        assertEquals(30, d.analysisFps)
        assertEquals(0f, SettingsCodec.decode(mapOf("gestureSensitivity" to "-3")).gestureSensitivity, 0f)
    }

    @Test fun `camera so e necessaria se algo a usa`() {
        assertTrue(NexusSettings().cameraNeeded)
        assertFalse(NexusSettings(cameraBackground = false, handTrackingEnabled = false).cameraNeeded)
        assertTrue(NexusSettings(cameraBackground = false, handTrackingEnabled = true).cameraNeeded)
    }

    private val demo get() = LocalExperienceRegistry.find(LocalExperienceRegistry.DEMO_WINDOW_ID)!!

    @Test fun `experiencia embutida e valida`() {
        assertTrue(ManifestValidator.validate(demo).isEmpty())
        assertEquals(InstallState.BUILT_IN, demo.installState)
    }

    @Test fun `validador rejeita manifestos ruins`() {
        val bad = demo.copy(id = "../x", name = " ", version = "1.0", minSdk = 0,
            requires = setOf(Capability.CAMERA), optional = setOf(Capability.CAMERA))
        assertEquals(5, ManifestValidator.validate(bad).size)
    }

    @Test fun `compatibilidade considera obrigatorias e opcionais`() {
        val all = DeviceCapabilities(34, setOf(Capability.TOUCH, Capability.CAMERA, Capability.HAND_TRACKING))
        assertEquals(Compatibility.OK, demo.checkCompatibility(all).level)

        val semMaos = DeviceCapabilities(34, setOf(Capability.TOUCH, Capability.CAMERA))
        val r = demo.checkCompatibility(semMaos)
        assertEquals(Compatibility.PARTIAL, r.level)
        assertTrue(r.notes.isNotEmpty())

        assertEquals(Compatibility.INCOMPATIBLE, demo.checkCompatibility(DeviceCapabilities(21, all.available)).level)

        val needsCam: ExperienceManifest = demo.copy(requires = setOf(Capability.CAMERA), optional = emptySet())
        assertEquals(Compatibility.INCOMPATIBLE, needsCam.checkCompatibility(DeviceCapabilities(34, setOf(Capability.TOUCH))).level)
    }

    @Test fun `mapeador FILL_CENTER recorta o excesso e centraliza`() {
        // imagem 400x300 (4:3) numa view 800x400 (2:1): escala = max(2, 1.333) = 2 => 800x600, sobra vertical
        val m = FillCenterMapper(400, 300, 800f, 400f)
        val c = m.map(0.5f, 0.5f)
        assertEquals(400f, c.x, 0.01f); assertEquals(200f, c.y, 0.01f)
        val tl = m.map(0f, 0f)
        assertEquals(0f, tl.x, 0.01f); assertEquals(-100f, tl.y, 0.01f)   // 100 px cortados no topo
        val mirrored = FillCenterMapper(400, 300, 800f, 400f, mirrorX = true).map(0f, 0.5f)
        assertEquals(800f, mirrored.x, 0.01f)
        assertNotNull(m)
    }
}
