# Reservado. Minificação está desligada no build release (ver app/build.gradle.kts).
# Ao ligar, validar em aparelho: -keep class com.google.mediapipe.** { *; }
