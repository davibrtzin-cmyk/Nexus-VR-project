# Arquitetura do NEXUS VR (Fase 1)

## Decisões e justificativas

**Tecnologia única: Kotlin nativo + Jetpack Compose (menus) + View/Canvas (cena imersiva).**
Sem Unity, Godot ou web. Motivos:

- Hardware de entrada (Realme C61): um motor 3D completo custa APK, memória e bateria sem benefício
  enquanto a interface é um conjunto de painéis 2D sobre o vídeo da câmera.
- CameraX e MediaPipe têm APIs nativas para Android; não precisam de ponte.
- Compose só nos menus (recomposição barata, produtividade). A cena imersiva usa uma `View` com
  `Canvas` que **só redesenha quando algo muda**: nada de loop de animação contínuo.
- Caminho de evolução: se um dia houver cena 3D real (estéreo com distorção de lente, ambientes),
  a `SpatialView` pode ser substituída por um renderizador OpenGL ES ou Filament sem tocar em
  `core/`, porque a renderização só consome o estado das janelas.

**Rastreamento de mãos: MediaPipe Hand Landmarker**, local, modo LIVE_STREAM, 1 mão, CPU.
Alternativas consideradas: ML Kit não tem hand landmarks; modelos ONNX/TFLite próprios exigiriam
treinar/validar e manter pré/pós-processamento. MediaPipe tem 21 landmarks, licença Apache 2.0 e
roda no aparelho. Risco conhecido: desempenho no C61 **ainda não medido**.

## Camadas

```
 câmera (CameraX) ─► HandFrameAnalyzer ─► HandTracker (MediaPipe) ─► landmarks[63]
                                                                        │
                          core/gesture/GestureEngine  ◄─────────────────┘
                          (pinça, histerese, debounce, suavização)
                                       │  PointerMove / Down / Up / Cancel / Exit
 toque (SpatialView.onTouchEvent) ─────┤
                                       ▼
                          core/window/WindowInteractor ──► WindowManager (dados das janelas)
                                       │ onBodyTap / onBodyScroll / onHudButton
                                       ▼
                          SpatialView (desenho) + WindowContent (conteúdo de cada janela)
```

- **`core/`** não importa nada de `android.*`. É onde mora a lógica que precisa ser confiável e
  testável: `GestureEngine`, `WindowManager`, `WindowInteractor`, `NexusSettings/SettingsCodec`,
  `ExperienceManifest/ManifestValidator`, `FillCenterMapper`.
- **Contrato entre reconhecimento e interface:** `PointerEvent` (`core/input`). O motor de gestos só
  produz esses eventos; a interface só os consome. Toque na tela usa o mesmo contrato
  (`InputSource.TOUCH`), então um controle Bluetooth futuro (`InputSource.KEY`) entra sem mudar janelas.
- **Novos tipos de janela:** implementar `WindowContent` e chamar `SpatialView.openWindow`. O
  gerenciador de janelas e o interator não conhecem tipos de conteúdo.
- **Biblioteca:** `ExperienceManifest` é só dado. Nenhum código é baixado ou executado. Um formato
  externo futuro terá de passar por `ManifestValidator` e por uma lista fechada de capacidades.

## Interação (requisito: sem mensagens a cada gesto)

- A pinça vira `PointerDown/Up`; o "clique" só dispara ao **soltar sobre o mesmo alvo** em que se
  pressionou (evita cliques acidentais e duplicados), com debounce de 150 ms após soltar.
- Feedback é visual e discreto: hover, estado pressionado e cursor em anel que se contrai.
  Nenhum texto é exibido por gesto. Fps, latência e valor da pinça ficam num canto, só se
  "Exibir diagnóstico" estiver ligado em Configurações.
- Mão perdida durante a pinça gera `PointerCancel` (não é clique) e o cursor some.

## Ciclo de vida e desempenho

- Câmera, MediaPipe e watchdog existem só entre `onStart` e `onStop` da `ImmersiveActivity`.
- Análise fora da thread principal (executor próprio); resultados voltam à thread de UI.
- FPS (10–30) e resolução (320×240 a 640×480) configuráveis; padrão 15 fps e 320×240.
- Quadros excedentes são descartados antes de qualquer processamento; bitmaps reutilizados em pool de 2.
- Qualidade gráfica "Baixa" desliga sombras e brilhos.
- Meta de desempenho: **nenhum número foi medido ainda.**

## Limitações da plataforma (documentadas, não escondidas)

- Câmera única traseira: sem estéreo, sem profundidade, sem rastreamento espacial.
- As coordenadas da mão são mapeadas para a tela supondo que Preview e análise têm o mesmo campo de
  visão (ambos 4:3); isso vale em aparelhos que honram a proporção pedida e deve ser verificado no C61.
- A imagem é renderizada em **tela única**. Um VR Box precisa de duas imagens lado a lado com
  correção de lente: **não implementado** (próximo passo natural após validar o núcleo).
- Com a câmera traseira apontada para fora, a mão precisa estar à frente do aparelho, o que no VR Box
  exige que o usuário tenha o campo de visão da câmera livre.
