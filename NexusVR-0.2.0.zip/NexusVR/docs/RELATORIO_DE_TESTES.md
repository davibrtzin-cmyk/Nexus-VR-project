# Relatório de testes (0.2.0, protótipo)

Data: 2026-10-13. Ambiente: container Linux, JDK 21, Kotlin 2.0.21 (`kotlinc`), JUnit 4.13.2.
**Sem Android SDK e sem acesso ao Google Maven/Maven Central**, portanto o módulo Android não foi
compilado aqui.

## Resultado executado

`scripts/run_core_tests.sh`: compila `core/` e os testes, roda JUnit.

```
== compilando núcleo ==
== compilando testes ==
== executando: com.nexusvr.core.GestureEngineTest com.nexusvr.core.SettingsAndExperienceTest com.nexusvr.core.WindowTest
JUnit version 4.13.2
...................................
Time: 0.054

OK (50 tests)
```

Compilação do núcleo e dos testes sem erros nem avisos exibidos.

## Novidades da 0.2.0

Testados na JVM (15 testes novos): geometria do modo VR Box (conversão tela↔cena nos dois olhos, paralaxe),
cursor do controle Bluetooth (zona morta, limites, Down/Up, cancelamento), estrelas determinísticas,
novas configurações, catálogo de apps e validação das experiências da biblioteca.
Um teste inicial falhou por exigir um ponto na borda do olho, que o deslocamento joga para fora do recorte
(invisível); o teste foi restringido à região visível. **Não executados em aparelho nem compilados:** renderização
VR Box, ambientes, relógio, galeria, ferramentas, lançador, leitura de gamepad. Todo esse código Android foi só revisado por leitura.

## Por módulo

| Módulo | Implementado | Testado | Passou | Falhou | Depende de teste físico | Limitações |
|---|---|---|---|---|---|---|
| Gestos (`GestureEngine`) | pinça com histerese, filtro de 2 quadros, debounce, suavização, cancelamento por mão perdida | 10 testes | 10 | 0 | Limiares (0,22–0,40 da razão polegar–indicador/tamanho da mão) foram escolhidos por raciocínio, não calibrados com mãos reais | Uma mão; sem gestos além de pinça |
| Janelas (`WindowManager`, `WindowInteractor`) | abrir, fechar, foco, mover, redimensionar, minimizar, restaurar, dock, rolagem, botão fixo | 17 testes | 17 | 0 | Sensação de arrastar/rolar com a mão | Só uma janela de demonstração existe |
| Configurações (`SettingsCodec`) | codificar/decodificar, valores inválidos, limites | 3 testes | 3 | 0 | Persistência real em SharedPreferences (a camada Android que a chama não foi executada) | Bluetooth e áudio: marcados "em desenvolvimento" na tela |
| Biblioteca (`ExperienceManifest`, validador, compatibilidade) | manifestos, validação, compatibilidade obrigatória/opcional | 4 testes | 4 | 0 | Tela da biblioteca em aparelho | Só experiência embutida; sem download |
| Mapeamento de coordenadas (`FillCenterMapper`) | recorte FILL_CENTER | 1 teste | 1 | 0 | Alinhamento real entre cursor e mão no C61 | Supõe Preview e análise com o mesmo campo de visão |
| Menu inicial, configurações (Compose) | implementado | **não** | n/a | n/a | Tudo | Não compilado |
| Fluxo de entrada, câmera (CameraX) | implementado | **não** | n/a | n/a | Tudo | Não compilado |
| Rastreamento (MediaPipe) | implementado | **não** | n/a | n/a | Tudo, incluindo fps e latência | Precisa do `.task`; não compilado |
| SpatialView, janela de demonstração | implementado | **não** | n/a | n/a | Tudo | Não compilado |

## Revisão estática da camada Android

Como não foi possível compilar, o código Android foi lido arquivo por arquivo conferindo: assinaturas
de CameraX 1.4 (`ResolutionSelector`, `AspectRatioStrategy`, `ResolutionStrategy`), MediaPipe Tasks
(`HandLandmarker`, `ImageProcessingOptions`, `BitmapImageBuilder`), Compose (escopos `RowScope`/`ColumnScope`),
ordem de liberação de recursos (câmera antes do rastreador), thread dos callbacks e conflitos de nomes
(`WindowManager` do núcleo vs. `android.view.WindowManager`). **Nenhum defeito foi encontrado, mas
leitura não substitui compilador.** Espere pequenos ajustes no primeiro sync/build.

## O que NÃO foi verificado (e não deve ser assumido)

- Que o projeto compila no Gradle (versões de AGP, Kotlin, CameraX, MediaPipe e BOM não resolvidas).
- Que a câmera abre, que o MediaPipe detecta a mão, o fps e a latência no Realme C61.
- Que a pinça é detectada de forma confiável e que o cursor coincide com a mão.
- Consumo de bateria, temperatura, memória, estabilidade em sessões longas.
- Comportamento em rotação, interrupção por chamada, volta do segundo plano.

## Roteiro de teste físico (primeiro passo ao receber o aparelho)

1. `./gradlew :app:assembleDebug` e instalar. Anotar qualquer erro de compilação.
2. Menu abre sem pedir câmera. Configurações: alterar valores, fechar o app, reabrir: valores mantidos.
3. Iniciar experiência sem o modelo `.task`: aviso claro, controle por toque funciona.
4. Com o modelo: ligar "Mostrar esqueleto" e "Exibir diagnóstico"; verificar esqueleto sobre a mão,
   fps ≥ 10 e latência estável em 320×240/15 fps.
5. Pinça sobre botão da janela: contador sobe 1 por pinça, sem texto de diagnóstico na tela.
6. Pinça mantida na barra de título: arrasta. Alça do canto: redimensiona. Corpo: rola a lista.
7. Tirar a mão do campo durante a pinça: nada é acionado. Sair e voltar ao app: câmera é reaberta.
8. Negar a permissão: tela explicativa, opção de continuar só com toque ou voltar ao menu.
