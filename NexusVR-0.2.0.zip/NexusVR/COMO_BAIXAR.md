# Como baixar o app (celular)

1. No GitHub, abra o repositório e toque em **Releases** (ou abra `.../releases/latest`).
2. Na versão mais recente, toque em **NEXUS-VR.apk** para baixar.
3. Abra o arquivo baixado e, se o Android pedir, permita **instalar de fonte desconhecida**.

A Release é criada sozinha pelo GitHub toda vez que você sobe uma versão nova do projeto (leva uns 10 minutos).
Se a compilação falhar, o aviso aparece em **Actions**; copie o erro e mande para o Claude corrigir.
