#!/usr/bin/env bash
# Baixa o modelo oficial do MediaPipe Hand Landmarker (Apache 2.0) para os assets do app.
# O arquivo NÃO é versionado. Sem ele o app funciona, mas só com toque (e informa isso ao usuário).
set -euo pipefail
DEST="$(cd "$(dirname "$0")/.." && pwd)/app/src/main/assets"
mkdir -p "$DEST"
URL="https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/latest/hand_landmarker.task"
curl -fL --retry 3 -o "$DEST/hand_landmarker.task" "$URL"
echo "OK: $(ls -l "$DEST/hand_landmarker.task")"
