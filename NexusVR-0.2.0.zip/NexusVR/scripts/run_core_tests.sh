#!/usr/bin/env bash
# Compila o núcleo (app/src/main/java/com/nexusvr/core) e roda os testes unitários na JVM,
# SEM Android SDK e SEM Gradle. Serve para validar a lógica pura (gestos, janelas, configurações,
# biblioteca) em qualquer máquina com JDK 17+ e o compilador Kotlin (kotlinc).
#
# Uso:  scripts/run_core_tests.sh
# Variáveis opcionais:
#   KOTLINC       caminho do kotlinc (padrão: o do PATH)
#   JUNIT_JAR     junit-4.13.2.jar
#   HAMCREST_JAR  hamcrest-core-1.3.jar
#   KOTLIN_STDLIB kotlin-stdlib-*.jar
#
# Obs.: o Gradle faz o mesmo com `./gradlew :app:testDebugUnitTest`; este script existe para
# ambientes sem acesso ao Google Maven (onde o AGP não resolve).
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SRC="$ROOT/app/src"
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT

KOTLINC="${KOTLINC:-kotlinc}"
command -v "$KOTLINC" >/dev/null || { echo "kotlinc não encontrado (defina KOTLINC)"; exit 2; }

find_jar() { # $1=variável  $2=padrão de nome
  local v="${!1:-}"
  if [[ -n "$v" ]]; then echo "$v"; return; fi
  find / -name "$2" -not -path '*/proc/*' 2>/dev/null | head -n1
}
JUNIT_JAR="$(find_jar JUNIT_JAR 'junit-4.13*.jar')"
HAMCREST_JAR="$(find_jar HAMCREST_JAR 'hamcrest-core-1.3*.jar')"
STDLIB="$(find_jar KOTLIN_STDLIB 'kotlin-stdlib-2*.jar')"
for j in "$JUNIT_JAR" "$HAMCREST_JAR" "$STDLIB"; do
  [[ -f "$j" ]] || { echo "JAR não encontrado: '$j' (defina JUNIT_JAR/HAMCREST_JAR/KOTLIN_STDLIB)"; exit 2; }
done

echo "== compilando núcleo =="
"$KOTLINC" -jvm-target 17 -no-stdlib -cp "$STDLIB" \
  $(find "$SRC/main/java/com/nexusvr/core" -name '*.kt') -d "$OUT/main"

echo "== compilando testes =="
"$KOTLINC" -jvm-target 17 -no-stdlib -cp "$STDLIB:$JUNIT_JAR:$OUT/main" \
  $(find "$SRC/test" -name '*.kt') -d "$OUT/test"

CLASSES=$(cd "$OUT/test" && find . -name '*Test.class' -not -name '*$*' | sed 's|^\./||; s|\.class$||; s|/|.|g' | sort | tr '\n' ' ')
echo "== executando: $CLASSES"
java -cp "$STDLIB:$JUNIT_JAR:$HAMCREST_JAR:$OUT/main:$OUT/test" org.junit.runner.JUnitCore $CLASSES
