# NEXUS VR

Plataforma Android de experiências virtuais e de realidade mista para VR Box.
Dispositivo inicial de teste: **Realme C61**. Versão atual: **0.1.0, protótipo** (ver "Maturidade").

> **Leia antes:** um VR Box é só um suporte de celular. O NEXUS VR mostra janelas 2D sobre o vídeo
> da câmera traseira. Isso **não é** realidade mista espacialmente consciente (sem profundidade,
> oclusão ou ancoragem no ambiente) e a imagem **ainda não é estereoscópica**.

## O que existe

| Módulo | Estado | Observação |
|---|---|---|
| Menu inicial (6 botões, estado do sistema, info do aparelho) | Implementado, não executado em aparelho | Todo botão leva a uma tela real; Ambientes e Aplicativos dizem "em desenvolvimento" |
| Configurações + persistência | Implementado; **lógica testada** na JVM | Armazenamento em SharedPreferences; leitura tolerante a dados inválidos |
| Fluxo de entrada na experiência | Implementado, não executado em aparelho | Verifica câmera, permissão, GL e modelo; só pede permissão se algo usa a câmera |
| Câmera real (CameraX, traseira) | Implementado, não executado em aparelho | Preview e análise independentes; liberados em `onStop` |
| Rastreamento de mãos (MediaPipe) | Implementado, não executado em aparelho | Precisa do arquivo `.task` (ver abaixo); sem ele o app opera só com toque e avisa |
| Pinça → eventos de ponteiro | Implementado; **lógica testada** na JVM | Histerese, filtro de ruído, debounce, cancelamento por mão perdida |
| Sistema de janelas | Implementado; **lógica testada** na JVM | Mover, redimensionar, minimizar, restaurar, fechar, foco, rolagem |
| Janela de demonstração | Implementado, não executado em aparelho | Chave, botão e lista rolável; sem mensagens a cada gesto |
| Biblioteca local | Implementado; **lógica testada** na JVM | Só experiências embutidas; validador de manifesto já existe |
| Ambientes, navegador, vídeo, galeria, Bluetooth, áudio, modo estéreo | **Não implementado** | Fases 9, 11 e 12 do roadmap |

## Gerar o APK sem computador (pelo celular)

1. Crie uma conta e um repositório **privado** no GitHub (pelo app ou site).
2. Envie o conteúdo desta pasta para o repositório (no site: "Add file" > "Upload files").
3. Aba **Actions** > **Gerar APK** > **Run workflow**. Leva alguns minutos.
4. Quando ficar verde, abra a execução e baixe **NEXUS-VR-apk** em *Artifacts* (vem como zip com `NEXUS-VR.apk`).
5. No Android, abra o `NEXUS-VR.apk` e permita "instalar apps desconhecidos" para o navegador/gerenciador de arquivos.

O modelo de mãos é baixado automaticamente na compilação (tarefa `fetchHandModel`), então não precisa do passo 1 de "Como executar".
Este workflow **ainda não foi executado**: se falhar, o log da aba Actions mostra o erro; me mande o texto.

## Como executar

Requisitos: Android Studio (Ladybug ou mais novo) ou JDK 17 + Android SDK 35, e acesso ao Google Maven.

1. Baixe o modelo de mãos (Apache 2.0), uma vez: `scripts/fetch_hand_model.sh`
   (cria `app/src/main/assets/hand_landmarker.task`, que não é versionado).
2. Abra a pasta no Android Studio e deixe o Gradle sincronizar, ou rode `./gradlew :app:assembleDebug`.
3. Instale no Realme C61 com depuração USB (`./gradlew :app:installDebug`).
4. Coloque o aparelho na horizontal. Toque em **INICIAR EXPERIÊNCIA** e autorize a câmera.

> As versões de plugin e bibliotecas (AGP 8.7.3, Kotlin 2.0.21, CameraX 1.4.1, MediaPipe 0.10.20,
> Compose BOM 2024.12.01) foram escolhidas por compatibilidade conhecida, mas **não foram resolvidas
> contra o Maven** no ambiente de desenvolvimento (sem acesso). Se o sync reclamar de uma versão,
> ajuste-a; a primeira compilação real do módulo Android acontecerá na sua máquina.

### Testes sem Android

`scripts/run_core_tests.sh` compila o núcleo e roda os 35 testes unitários na JVM, sem Gradle nem SDK
(precisa de `kotlinc`, JDK 17+ e os JARs do JUnit 4). Com Gradle: `./gradlew :app:testDebugUnitTest`.
Resultado detalhado em [docs/RELATORIO_DE_TESTES.md](docs/RELATORIO_DE_TESTES.md).

## Estrutura

```
app/src/main/java/com/nexusvr/
  core/        Lógica pura (sem Android, testável na JVM): gestos, janelas, configurações, biblioteca
  platform/    Ponte com o Android: SharedPreferences, informações do aparelho
  ui/          Menu inicial e configurações (Jetpack Compose)
  immersive/   Experiência imersiva: câmera, MediaPipe, SpatialView (Canvas), conteúdo das janelas
```

Detalhes e decisões em [docs/ARQUITETURA.md](docs/ARQUITETURA.md).

## Maturidade

Protótipo: a lógica central está verificada por testes, mas **nenhum código Android foi compilado
nem executado em aparelho**. Passos seguintes para chegar a "versão experimental": compilar,
instalar no Realme C61, medir fps/latência do rastreamento e ajustar limiares da pinça com mãos reais.
Não há avaliação de bateria, temperatura, nem testes de estabilidade. Não está pronto para publicação.

## Licenças e privacidade

- MediaPipe Tasks (Apache 2.0), CameraX, Jetpack Compose e AndroidX (Apache 2.0). Modelo
  `hand_landmarker` do Google (Apache 2.0, conferir os termos no momento do download).
- Nenhuma credencial no código. Única permissão: `CAMERA`, solicitada só ao entrar na experiência,
  com explicação. Imagens são processadas no aparelho; nada é gravado nem enviado.
- Marca, logotipo e interface são originais; nada copiado do Meta Quest ou do EnJoyTheMR.
