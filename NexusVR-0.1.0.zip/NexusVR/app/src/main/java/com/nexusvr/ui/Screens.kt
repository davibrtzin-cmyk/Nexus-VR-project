package com.nexusvr.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexusvr.core.experience.Compatibility
import com.nexusvr.core.experience.ExperienceManifest
import com.nexusvr.core.experience.LocalExperienceRegistry
import com.nexusvr.core.experience.checkCompatibility
import com.nexusvr.core.settings.AnalysisResolution
import com.nexusvr.core.settings.GraphicsQuality
import com.nexusvr.core.settings.NexusSettings
import com.nexusvr.core.settings.OrientationPref
import com.nexusvr.platform.DeviceInfo

enum class Screen { HOME, SETTINGS, LIBRARY, ENVIRONMENTS, APPS, HELP }

@Composable
fun ScreenFrame(title: String, onBack: () -> Unit, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 24.dp)) {
        Row(Modifier.fillMaxWidth().padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            NexusButton("‹  VOLTAR", onBack)
            Spacer(Modifier.padding(horizontal = 8.dp))
            Text(title, color = Nx.text, fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            content()
            Spacer(Modifier.height(32.dp))
        }
    }
}

@Composable
fun HomeScreen(
    info: DeviceInfo,
    settings: NexusSettings,
    onStart: () -> Unit,
    onOpen: (Screen) -> Unit,
) {
    val camLabel = when {
        !info.hasBackCamera -> "Sem câmera"
        info.cameraPermissionGranted -> "Câmera autorizada"
        else -> "Câmera: permissão pendente"
    }
    val handsLabel = when {
        !settings.handTrackingEnabled -> "Mãos: desativado"
        !info.handModelPresent -> "Mãos: modelo ausente (só toque)"
        else -> "Mãos: pronto"
    }
    val statusColor = when {
        !info.handModelPresent && settings.handTrackingEnabled -> Nx.warn
        !info.hasBackCamera && settings.cameraNeeded -> Nx.bad
        else -> Nx.ok
    }

    Row(Modifier.fillMaxSize().statusBarsPadding().padding(24.dp), horizontalArrangement = Arrangement.spacedBy(24.dp)) {
        // Coluna esquerda: identidade e ação principal
        Column(Modifier.weight(0.42f).fillMaxSize(), verticalArrangement = Arrangement.Center) {
            Text("NEXUS", color = Nx.text, fontSize = 44.sp, fontWeight = FontWeight.Black, letterSpacing = 8.sp)
            Text("V R", color = Nx.cyan, fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = 14.sp)
            Spacer(Modifier.height(8.dp))
            Text("Plataforma de realidade mista para Android", color = Nx.dim, fontSize = 13.sp)
            Spacer(Modifier.height(28.dp))
            NexusButton("INICIAR EXPERIÊNCIA", onStart, primary = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(20.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                StatusDot(statusColor)
                Spacer(Modifier.padding(horizontal = 5.dp))
                Text("Sistema: protótipo v0.1", color = Nx.dim, fontSize = 12.sp)
            }
        }

        // Coluna direita: módulos e dispositivo
        Column(Modifier.weight(0.58f).fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ModuleCard("CONFIGURAÇÕES", "Gráficos, mãos, câmera, diagnóstico", ModuleState.READY, { onOpen(Screen.SETTINGS) }, Modifier.weight(1f))
                ModuleCard("BIBLIOTECA", "Experiências incluídas no app", ModuleState.EXPERIMENTAL, { onOpen(Screen.LIBRARY) }, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ModuleCard("AMBIENTES", "Cenários virtuais", ModuleState.IN_DEVELOPMENT, { onOpen(Screen.ENVIRONMENTS) }, Modifier.weight(1f))
                ModuleCard("APLICATIVOS", "Navegador, vídeo, galeria", ModuleState.IN_DEVELOPMENT, { onOpen(Screen.APPS) }, Modifier.weight(1f))
            }
            ModuleCard("AJUDA", "Como usar com o VR Box e limitações", ModuleState.READY, { onOpen(Screen.HELP) }, Modifier.fillMaxWidth())

            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(Nx.panel)
                    .border(BorderStroke(1.dp, Nx.line), RoundedCornerShape(18.dp))
                    .padding(16.dp),
            ) {
                Text("DISPOSITIVO", color = Nx.cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Spacer(Modifier.height(8.dp))
                InfoLine("Aparelho", info.model)
                InfoLine("Android", "${info.androidRelease} (SDK ${info.sdk})")
                InfoLine("Recursos", "$camLabel · $handsLabel")
            }
        }
    }
}

@Composable
fun SettingsScreen(
    settings: NexusSettings,
    info: DeviceInfo,
    onChange: (NexusSettings) -> Unit,
    onReset: () -> Unit,
    onOpenAppSettings: () -> Unit,
    onBack: () -> Unit,
) {
    ScreenFrame("CONFIGURAÇÕES", onBack) {
        SectionTitle("Gráficos e desempenho")
        ChoiceRow(
            "Qualidade gráfica", "Baixa desliga sombras e brilhos da interface.",
            GraphicsQuality.entries, settings.graphicsQuality, { it.label },
        ) { onChange(settings.copy(graphicsQuality = it)) }
        ChoiceRow(
            "Resolução da análise", "Menor = mais leve para CPU e bateria; maior = mais preciso.",
            AnalysisResolution.entries, settings.analysisResolution, { "${it.w}×${it.h}" },
        ) { onChange(settings.copy(analysisResolution = it)) }
        ChoiceRow(
            "Frequência de análise", "Quadros por segundo processados pelo rastreamento.",
            NexusSettings.ALLOWED_FPS, settings.analysisFps, { "$it fps" },
        ) { onChange(settings.copy(analysisFps = it)) }

        SectionTitle("Interação")
        SwitchRow("Controle por mãos", "Usa a câmera para reconhecer a pinça. Desligado: só toque.", settings.handTrackingEnabled) {
            onChange(settings.copy(handTrackingEnabled = it))
        }
        SliderRow("Sensibilidade da pinça", "Maior = a pinça é detectada com os dedos mais afastados.", settings.gestureSensitivity) {
            onChange(settings.copy(gestureSensitivity = it))
        }
        SwitchRow("Mostrar esqueleto da mão", "Desenha os pontos detectados (útil para ajustar a distância).", settings.showHandSkeleton) {
            onChange(settings.copy(showHandSkeleton = it))
        }

        SectionTitle("Câmera e tela")
        SwitchRow("Fundo com câmera", "Mostra o ambiente real atrás das janelas. Sobreposição 2D, sem profundidade.", settings.cameraBackground) {
            onChange(settings.copy(cameraBackground = it))
        }
        ChoiceRow(
            "Orientação", "A experiência imersiva sempre usa paisagem.",
            OrientationPref.entries, settings.orientation,
            { when (it) { OrientationPref.SENSOR_LANDSCAPE -> "Auto"; OrientationPref.LANDSCAPE -> "Fixa"; OrientationPref.REVERSE_LANDSCAPE -> "Invertida" } },
        ) { onChange(settings.copy(orientation = it)) }
        SettingRow(
            "Permissão da câmera",
            if (info.cameraPermissionGranted) "Concedida. Só é usada dentro da experiência."
            else "Não concedida. Será solicitada ao iniciar a experiência, com explicação.",
        ) { NexusButton("AJUSTES DO APP", onOpenAppSettings) }

        SectionTitle("Ainda não disponível")
        SettingRow("Controles Bluetooth", "Fase 12 do roadmap. Sem implementação nesta versão.") { StateChip(ModuleState.IN_DEVELOPMENT) }
        SettingRow("Preferências de áudio", "Sem áudio nesta versão; será adicionado com o conteúdo multimídia.") { StateChip(ModuleState.IN_DEVELOPMENT) }

        SectionTitle("Diagnóstico")
        SwitchRow("Exibir diagnóstico na experiência", "Mostra fps, latência do rastreamento e valor da pinça num canto discreto.", settings.showDiagnostics) {
            onChange(settings.copy(showDiagnostics = it))
        }
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Nx.panel).padding(14.dp),
        ) {
            InfoLine("Aparelho", info.model)
            InfoLine("Android", "${info.androidRelease} (SDK ${info.sdk})")
            InfoLine("Memória", "${info.ramMb} MB")
            InfoLine("Núcleos de CPU", info.cpuCores.toString())
            InfoLine("OpenGL ES", info.glEsVersion)
            InfoLine("Câmera traseira", if (info.hasBackCamera) "sim" else "não")
            InfoLine("Giroscópio", if (info.hasGyroscope) "sim" else "não")
            InfoLine("Acelerômetro", if (info.hasAccelerometer) "sim" else "não")
            InfoLine("Modelo de mãos", if (info.handModelPresent) "incluído" else "AUSENTE")
        }

        SectionTitle("Sobre")
        InfoLine("Aplicativo", "NEXUS VR 0.1.0 (protótipo)")
        InfoLine("Rastreamento", "MediaPipe Hand Landmarker (Apache 2.0), local")
        InfoLine("Privacidade", "Nada é gravado ou enviado")
        Spacer(Modifier.height(16.dp))
        NexusButton("RESTAURAR PADRÕES", onReset)
    }
}

@Composable
fun LibraryScreen(info: DeviceInfo, onBack: () -> Unit) {
    ScreenFrame("BIBLIOTECA", onBack) {
        Text(
            "Experiências incluídas no aplicativo. Não há download nem execução de código externo.",
            color = Nx.dim, fontSize = 13.sp,
        )
        Spacer(Modifier.height(12.dp))
        for (m in LocalExperienceRegistry.all) ExperienceCard(m, info)
    }
}

@Composable
private fun ExperienceCard(m: ExperienceManifest, info: DeviceInfo) {
    val report = m.checkCompatibility(info.capabilities())
    val (label, color) = when (report.level) {
        Compatibility.OK -> "Compatível" to Nx.ok
        Compatibility.PARTIAL -> "Compatível com limitações" to Nx.warn
        Compatibility.INCOMPATIBLE -> "Incompatível" to Nx.bad
    }
    val shape = RoundedCornerShape(18.dp)
    Column(
        Modifier.fillMaxWidth().clip(shape).background(Nx.panel).border(BorderStroke(1.dp, Nx.line), shape).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Text(m.name, color = Nx.text, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Text(m.description, color = Nx.dim, fontSize = 13.sp)
        InfoLine("Versão", m.version)
        InfoLine("Estado", m.installState.label)
        InfoLine("Requer", m.requires.joinToString { it.label })
        if (m.optional.isNotEmpty()) InfoLine("Opcional", m.optional.joinToString { it.label })
        Row(verticalAlignment = Alignment.CenterVertically) {
            StatusDot(color)
            Spacer(Modifier.padding(horizontal = 4.dp))
            Text(label, color = color, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        }
        for (n in report.notes) Text("• $n", color = Nx.dim, fontSize = 12.sp)
        Spacer(Modifier.height(4.dp))
        Text("Como usar", color = Nx.cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        Text(m.instructions, color = Nx.text, fontSize = 13.sp)
    }
}

@Composable
fun InDevelopmentScreen(title: String, what: String, plan: String, onBack: () -> Unit) {
    ScreenFrame(title, onBack) {
        StateChip(ModuleState.IN_DEVELOPMENT)
        Spacer(Modifier.height(12.dp))
        Text(what, color = Nx.text, fontSize = 15.sp)
        Spacer(Modifier.height(12.dp))
        Text("Planejado", color = Nx.cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Text(plan, color = Nx.dim, fontSize = 13.sp)
    }
}

@Composable
fun HelpScreen(onBack: () -> Unit) {
    ScreenFrame("AJUDA", onBack) {
        SectionTitle("Como começar")
        HelpText("1. Coloque o celular no VR Box na horizontal. 2. Toque em INICIAR EXPERIÊNCIA. 3. Autorize a câmera quando solicitado.")
        SectionTitle("Gestos")
        HelpText("Pinça (polegar + indicador) sobre um elemento: seleciona. Pinça mantida e movimento: arrasta janelas pela barra de título, ou redimensiona pela alça no canto. Pinça sobre o corpo da janela e movimento vertical: rola listas. Sem mãos: toque na tela.")
        HelpText("Mantenha a mão a cerca de 30–60 cm da câmera traseira, com boa iluminação e a palma voltada para ela. Ative “Mostrar esqueleto da mão” nas configurações para ajustar.")
        SectionTitle("Limitações")
        HelpText("Um VR Box é apenas um suporte de celular. O NEXUS VR mostra janelas 2D sobre o vídeo da câmera: não há profundidade, oclusão nem ancoragem no ambiente, e a imagem não é estereoscópica nesta versão.")
        HelpText("O rastreamento usa a câmera traseira com a mão à frente do aparelho; funciona de forma diferente em cada celular e a precisão depende da luz e do desempenho do aparelho.")
        SectionTitle("Privacidade")
        HelpText("A câmera só é ativada dentro da experiência. As imagens são processadas no aparelho e não são gravadas nem enviadas.")
    }
}

@Composable
private fun HelpText(t: String) {
    Text(t, color = Nx.text, fontSize = 14.sp, lineHeight = 20.sp, modifier = Modifier.padding(bottom = 8.dp))
}
