package com.nexusvr.immersive

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import com.nexusvr.core.Box
import com.nexusvr.core.input.InputSource
import com.nexusvr.core.input.PointerCancel
import com.nexusvr.core.input.PointerDown
import com.nexusvr.core.input.PointerEvent
import com.nexusvr.core.input.PointerMove
import com.nexusvr.core.input.PointerUp
import com.nexusvr.core.settings.GraphicsQuality
import com.nexusvr.core.window.Hit
import com.nexusvr.core.window.HudButton
import com.nexusvr.core.window.InteractionListener
import com.nexusvr.core.window.Part
import com.nexusvr.core.window.VirtualWindow
import com.nexusvr.core.window.WindowInteractor
import com.nexusvr.core.window.WindowManager
import com.nexusvr.core.window.WindowMetrics
import com.nexusvr.core.window.WindowState

/**
 * Camada espacial 2D: desenha janelas virtuais, dock, botão de menu e cursor da mão sobre o fundo
 * (vídeo da câmera ou cor sólida). Só redesenha quando algo muda (sem loop de animação contínuo).
 *
 * Importante: isto é uma sobreposição digital sobre o vídeo da câmera, NÃO realidade mista
 * espacialmente consciente (não há profundidade, oclusão nem ancoragem no ambiente).
 */
class SpatialView(context: Context) : View(context), InteractionListener {

    private val density = resources.displayMetrics.density
    private val style = SpatialStyle(density)

    val windows = WindowManager(
        WindowMetrics(
            titleH = 52f * density, button = 40f * density, handle = 40f * density,
            dockH = 44f * density, dockItemW = 150f * density, margin = 12f * density,
            minW = 260f * density, minH = 190f * density,
        ),
    )
    val interactor = WindowInteractor(windows, slopPx = 14f * density)

    private val contents = HashMap<Int, WindowContent>()
    private var skeleton: FloatArray? = null
    private var firstLayout = true

    var quality: GraphicsQuality = GraphicsQuality.MEDIUM
        set(v) { field = v; style.fancy = v != GraphicsQuality.LOW; invalidate() }
    var showSkeleton = false
    var onMenuRequested: (() -> Unit)? = null

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()

    init {
        interactor.listener = this
        interactor.onChanged = { invalidate() }
        windows.onClosed = { id -> contents.remove(id) }
        style.fancy = quality != GraphicsQuality.LOW
    }

    // ---- API usada pela Activity ----

    /** Eventos vindos do rastreamento de mãos (já em pixels desta view). */
    fun dispatch(events: List<PointerEvent>) {
        if (events.isEmpty()) return
        for (e in events) interactor.onEvent(e)
    }

    /** Pontos da mão em pixels: x0,y0,x1,y1,... (21 pontos). null apaga. */
    fun setSkeleton(points: FloatArray?) {
        skeleton = points
        invalidate()
    }

    fun openWindow(typeId: String, title: String, box: Box, content: WindowContent): VirtualWindow {
        val w = windows.open(typeId, title, box)
        contents[w.id] = content
        invalidate()
        return w
    }

    /** Chamado uma única vez, quando o tamanho da view é conhecido, para abrir as janelas iniciais. */
    var onFirstLayout: ((width: Int, height: Int) -> Unit)? = null

    // ---- layout ----

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        windows.setBounds(w.toFloat(), h.toFloat())
        val bw = 120f * density
        val bh = 44f * density
        val m = 14f * density
        val existing = interactor.hudButtons.firstOrNull { it.id == HUD_MENU }
        if (existing != null) existing.box = Box(m, m, bw, bh)
        else interactor.hudButtons += HudButton(HUD_MENU, Box(m, m, bw, bh))
        if (firstLayout && w > 0 && h > 0) {
            firstLayout = false
            onFirstLayout?.invoke(w, h)
        }
    }

    // ---- toque (mesma lógica de interação da mão) ----

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(ev: MotionEvent): Boolean {
        val x = ev.x
        val y = ev.y
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                interactor.onEvent(PointerMove(x, y, InputSource.TOUCH))
                interactor.onEvent(PointerDown(x, y, InputSource.TOUCH))
            }
            MotionEvent.ACTION_MOVE -> interactor.onEvent(PointerMove(x, y, InputSource.TOUCH))
            MotionEvent.ACTION_UP -> interactor.onEvent(PointerUp(x, y, InputSource.TOUCH))
            MotionEvent.ACTION_CANCEL -> interactor.onEvent(PointerCancel(x, y, InputSource.TOUCH))
        }
        return true
    }

    // ---- InteractionListener ----

    override fun onBodyTap(window: VirtualWindow, localX: Float, localY: Float) {
        contents[window.id]?.onTap(localX, localY)
    }

    override fun onBodyScroll(window: VirtualWindow, dy: Float) {
        contents[window.id]?.onScroll(dy)
    }

    override fun onHudButton(id: String) {
        if (id == HUD_MENU) onMenuRequested?.invoke()
    }

    // ---- desenho ----

    override fun onDraw(canvas: Canvas) {
        val focused = windows.focusedId
        for (w in windows.windows) {
            if (w.state == WindowState.NORMAL) drawWindow(canvas, w, w.id == focused)
        }
        drawDock(canvas)
        drawHud(canvas)
        drawSkeleton(canvas)
        drawCursor(canvas)
    }

    private fun partState(winId: Int, part: Part): Int {
        val h = Hit(winId, part)
        return when {
            interactor.pressed && interactor.pressedHit == h -> 2
            interactor.hoverHit == h -> 1
            else -> 0
        }
    }

    private fun drawWindow(canvas: Canvas, w: VirtualWindow, focused: Boolean) {
        val d = density
        val b = w.box
        val corner = 16f * d
        if (style.fancy) {
            r.set(b.x + 3f * d, b.y + 6f * d, b.right + 3f * d, b.bottom + 6f * d)
            canvas.drawRoundRect(r, corner, corner, p.fill(0x55000000))
        }
        r.set(b)
        canvas.drawRoundRect(r, corner, corner, p.fill(style.bgPanel))

        // barra de título
        val save = canvas.save()
        r.set(b)
        canvas.clipRect(r)
        r.set(b.x, b.y, b.right, b.y + windows.metrics.titleH)
        canvas.drawRect(r, p.fill(style.bgTitle))
        canvas.restoreToCount(save)

        p.fill(if (focused) style.text else style.textDim)
        p.textSize = style.sp(16f)
        p.typeface = Typeface.DEFAULT_BOLD
        canvas.drawText(w.title, b.x + 18f * d, b.y + windows.metrics.titleH / 2f + 6f * d, p)

        drawButton(canvas, windows.minimizeBox(w), partState(w.id, Part.MINIMIZE), false)
        drawButton(canvas, windows.closeBox(w), partState(w.id, Part.CLOSE), true)

        // conteúdo
        val body = windows.bodyBox(w)
        val c = contents[w.id]
        if (c != null && body.h > 0f) {
            val s = canvas.save()
            canvas.clipRect(body.x, body.y, body.right, body.bottom)
            c.draw(canvas, body, style)
            canvas.restoreToCount(s)
        }

        // alça de redimensionar (três riscos diagonais)
        val rs = windows.resizeBox(w)
        val rsState = partState(w.id, Part.RESIZE)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f * d
        p.strokeCap = Paint.Cap.ROUND
        p.color = if (rsState == 2) style.accent else if (rsState == 1) style.text else style.textDim
        val x1 = rs.right - 8f * d
        val y1 = rs.bottom - 8f * d
        for (k in 0..2) {
            val o = k * 7f * d
            canvas.drawLine(x1 - o, y1, x1, y1 - o, p)
        }
        p.style = Paint.Style.FILL

        // borda: destaque discreto na janela em foco
        r.set(b)
        p.style = Paint.Style.STROKE
        p.strokeWidth = (if (focused) 2f else 1f) * d
        p.color = if (focused) style.accent else 0x55FFFFFF
        canvas.drawRoundRect(r, corner, corner, p)
        p.style = Paint.Style.FILL
    }

    private fun drawButton(canvas: Canvas, box: Box, state: Int, isClose: Boolean) {
        val d = density
        r.set(box)
        val base = when (state) {
            2 -> if (isClose) style.danger else style.accent
            1 -> 0x44FFFFFF
            else -> 0x22FFFFFF
        }
        canvas.drawRoundRect(r, 10f * d, 10f * d, p.fill(base))
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2.4f * d
        p.strokeCap = Paint.Cap.ROUND
        p.color = if (state == 2) 0xFF07101C.toInt() else style.text
        val cx = r.centerX()
        val cy = r.centerY()
        val s = 7f * d
        if (isClose) {
            canvas.drawLine(cx - s, cy - s, cx + s, cy + s, p)
            canvas.drawLine(cx - s, cy + s, cx + s, cy - s, p)
        } else {
            canvas.drawLine(cx - s, cy + s * 0.6f, cx + s, cy + s * 0.6f, p)
        }
        p.style = Paint.Style.FILL
    }

    private fun drawDock(canvas: Canvas) {
        val min = windows.minimizedWindows()
        if (min.isEmpty()) return
        val d = density
        for ((i, w) in min.withIndex()) {
            val box = windows.dockBox(i)
            r.set(box)
            val st = if (interactor.pressed && interactor.pressedHit == Hit(w.id, Part.DOCK)) 2
            else if (interactor.hoverHit == Hit(w.id, Part.DOCK)) 1 else 0
            canvas.drawRoundRect(r, 12f * d, 12f * d, p.fill(if (st == 2) style.pressedFill else style.bgPanel))
            p.style = Paint.Style.STROKE
            p.strokeWidth = 1.5f * d
            p.color = if (st == 0) 0x55FFFFFF else style.accent
            canvas.drawRoundRect(r, 12f * d, 12f * d, p)
            p.style = Paint.Style.FILL
            p.fill(style.text).textSize = style.sp(14f)
            p.typeface = Typeface.DEFAULT
            val title = if (w.title.length > 16) w.title.take(15) + "…" else w.title
            canvas.drawText(title, r.left + 14f * d, r.centerY() + 5f * d, p)
        }
    }

    private fun drawHud(canvas: Canvas) {
        val d = density
        for (hb in interactor.hudButtons) {
            r.set(hb.box)
            val st = if (interactor.pressed && interactor.pressedHud == hb.id) 2
            else if (interactor.hoverHud == hb.id) 1 else 0
            canvas.drawRoundRect(r, 22f * d, 22f * d, p.fill(if (st == 2) style.pressedFill else 0x99070B14.toInt()))
            p.style = Paint.Style.STROKE
            p.strokeWidth = 1.5f * d
            p.color = if (st == 0) 0x66FFFFFF else style.accent
            canvas.drawRoundRect(r, 22f * d, 22f * d, p)
            p.style = Paint.Style.FILL
            p.fill(style.text).textSize = style.sp(14f)
            p.typeface = Typeface.DEFAULT_BOLD
            p.textAlign = Paint.Align.CENTER
            canvas.drawText("MENU", r.centerX(), r.centerY() + 5f * d, p)
            p.textAlign = Paint.Align.LEFT
        }
    }

    private fun drawSkeleton(canvas: Canvas) {
        val pts = skeleton ?: return
        if (!showSkeleton || pts.size < 42) return
        val d = density
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f * d
        p.color = 0x883DE8FF.toInt()
        for (i in BONES.indices step 2) {
            val a = BONES[i] * 2
            val b = BONES[i + 1] * 2
            canvas.drawLine(pts[a], pts[a + 1], pts[b], pts[b + 1], p)
        }
        p.style = Paint.Style.FILL
        p.color = style.accent
        for (i in 0 until 21) canvas.drawCircle(pts[i * 2], pts[i * 2 + 1], 3f * d, p)
    }

    /** Cursor só para a mão (o toque não precisa). Anel; preenche levemente durante a pinça. */
    private fun drawCursor(canvas: Canvas) {
        if (!interactor.cursorVisible || interactor.cursorSource != InputSource.HAND) return
        val d = density
        val pressed = interactor.pressed
        val radius = (if (pressed) 9f else 13f) * d
        if (pressed) canvas.drawCircle(interactor.cursorX, interactor.cursorY, radius, p.fill(0x883DE8FF.toInt()))
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2.5f * d
        p.color = style.accent
        canvas.drawCircle(interactor.cursorX, interactor.cursorY, radius, p)
        p.style = Paint.Style.FILL
    }

    companion object {
        const val HUD_MENU = "menu"

        private val BONES = intArrayOf(
            0, 1, 1, 2, 2, 3, 3, 4, 0, 5, 5, 6, 6, 7, 7, 8, 5, 9, 9, 10, 10, 11, 11, 12,
            9, 13, 13, 14, 14, 15, 15, 16, 13, 17, 17, 18, 18, 19, 19, 20, 0, 17,
        )
    }
}
