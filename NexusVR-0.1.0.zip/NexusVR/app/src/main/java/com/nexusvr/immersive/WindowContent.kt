package com.nexusvr.immersive

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import com.nexusvr.core.Box

/** Paleta/estilo compartilhado pelo desenho das janelas e dos conteúdos. */
class SpatialStyle(val density: Float) {
    var fancy: Boolean = true   // brilho e sombra; desligado em qualidade gráfica Baixa

    val bgPanel = 0xEB0E1626.toInt()
    val bgTitle = 0xFF152238.toInt()
    val accent = 0xFF3DE8FF.toInt()
    val accent2 = 0xFF7C5CFF.toInt()
    val text = 0xFFE6F1FF.toInt()
    val textDim = 0xFF8FA3BF.toInt()
    val danger = 0xFFFF5C7A.toInt()
    val hover = 0x33FFFFFF
    val pressedFill = 0x663DE8FF

    fun dp(v: Float) = v * density
    fun sp(v: Float) = v * density
}

/**
 * Conteúdo desenhado dentro do corpo de uma janela. Novos tipos de janela (vídeo, galeria,
 * navegador…) implementam esta interface e são registrados na SpatialView, sem tocar no
 * gerenciador de janelas nem no motor de interação.
 */
interface WindowContent {
    /** Desenha dentro de [body] (coordenadas da view). O canvas já está recortado ao corpo. */
    fun draw(canvas: Canvas, body: Box, style: SpatialStyle)

    /** Toque/pinça em coordenadas locais ao corpo. */
    fun onTap(localX: Float, localY: Float) {}

    fun onScroll(dy: Float) {}
}

internal fun RectF.set(b: Box) = set(b.x, b.y, b.right, b.bottom)

internal fun Paint.fill(color: Int): Paint { style = Paint.Style.FILL; this.color = color; return this }
