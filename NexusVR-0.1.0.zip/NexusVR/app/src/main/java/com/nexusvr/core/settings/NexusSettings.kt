package com.nexusvr.core.settings

enum class GraphicsQuality(val label: String) {
    LOW("Baixa"), MEDIUM("Média"), HIGH("Alta")
}

enum class AnalysisResolution(val w: Int, val h: Int, val label: String) {
    R320(320, 240, "320×240 (mais leve)"),
    R480(480, 360, "480×360"),
    R640(640, 480, "640×480 (mais preciso)"),
}

enum class OrientationPref(val label: String) {
    SENSOR_LANDSCAPE("Paisagem automática"),
    LANDSCAPE("Paisagem fixa"),
    REVERSE_LANDSCAPE("Paisagem invertida"),
}

data class NexusSettings(
    val graphicsQuality: GraphicsQuality = GraphicsQuality.MEDIUM,
    val analysisResolution: AnalysisResolution = AnalysisResolution.R320,
    val analysisFps: Int = 15,
    val handTrackingEnabled: Boolean = true,
    val gestureSensitivity: Float = 0.5f,
    val showHandSkeleton: Boolean = false,
    val cameraBackground: Boolean = true,
    val orientation: OrientationPref = OrientationPref.SENSOR_LANDSCAPE,
    val showDiagnostics: Boolean = false,
) {
    /** A câmera só é aberta (e a permissão só pedida) se algo a usa. */
    val cameraNeeded: Boolean get() = cameraBackground || handTrackingEnabled

    companion object {
        val ALLOWED_FPS = listOf(10, 15, 20, 30)
    }
}

/** Serialização tolerante: valor ausente/inválido volta ao padrão; números são limitados à faixa válida. */
object SettingsCodec {
    fun encode(s: NexusSettings): Map<String, String> = mapOf(
        "graphicsQuality" to s.graphicsQuality.name,
        "analysisResolution" to s.analysisResolution.name,
        "analysisFps" to s.analysisFps.toString(),
        "handTrackingEnabled" to s.handTrackingEnabled.toString(),
        "gestureSensitivity" to s.gestureSensitivity.toString(),
        "showHandSkeleton" to s.showHandSkeleton.toString(),
        "cameraBackground" to s.cameraBackground.toString(),
        "orientation" to s.orientation.name,
        "showDiagnostics" to s.showDiagnostics.toString(),
    )

    fun decode(m: Map<String, String>): NexusSettings {
        val d = NexusSettings()
        return NexusSettings(
            graphicsQuality = enumOr(m["graphicsQuality"], d.graphicsQuality),
            analysisResolution = enumOr(m["analysisResolution"], d.analysisResolution),
            analysisFps = nearestFps(m["analysisFps"]?.toIntOrNull(), d.analysisFps),
            handTrackingEnabled = m["handTrackingEnabled"]?.toBooleanStrictOrNull() ?: d.handTrackingEnabled,
            gestureSensitivity = (m["gestureSensitivity"]?.toFloatOrNull() ?: d.gestureSensitivity)
                .let { if (it.isNaN()) d.gestureSensitivity else it.coerceIn(0f, 1f) },
            showHandSkeleton = m["showHandSkeleton"]?.toBooleanStrictOrNull() ?: d.showHandSkeleton,
            cameraBackground = m["cameraBackground"]?.toBooleanStrictOrNull() ?: d.cameraBackground,
            orientation = enumOr(m["orientation"], d.orientation),
            showDiagnostics = m["showDiagnostics"]?.toBooleanStrictOrNull() ?: d.showDiagnostics,
        )
    }

    private inline fun <reified E : Enum<E>> enumOr(raw: String?, default: E): E =
        raw?.let { r -> enumValues<E>().firstOrNull { it.name == r } } ?: default

    private fun nearestFps(v: Int?, default: Int): Int =
        if (v == null) default else NexusSettings.ALLOWED_FPS.minByOrNull { kotlin.math.abs(it - v) } ?: default
}
