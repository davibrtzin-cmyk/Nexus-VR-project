package com.nexusvr.core.experience

enum class Capability(val label: String) {
    TOUCH("Toque"),
    CAMERA("Câmera"),
    HAND_TRACKING("Rastreamento de mãos"),
}

enum class InstallState(val label: String) {
    BUILT_IN("Incluída no app"),
    INSTALLED("Instalada"),
    AVAILABLE("Disponível"),
}

/**
 * Metadados de uma experiência. É apenas DADO: nenhuma experiência executa código baixado.
 * Um futuro formato externo terá de passar por [ManifestValidator] e por uma lista fechada de
 * capacidades; carregar código arbitrário da internet está fora do escopo.
 */
data class ExperienceManifest(
    val id: String,
    val name: String,
    val description: String,
    val version: String,
    val minSdk: Int,
    val requires: Set<Capability>,
    val optional: Set<Capability>,
    val installState: InstallState,
    val instructions: String,
)

/** O que o aparelho oferece agora. Montado por quem conhece o Android (ver DeviceInfoProvider). */
data class DeviceCapabilities(val sdk: Int, val available: Set<Capability>)

enum class Compatibility { OK, PARTIAL, INCOMPATIBLE }

data class CompatibilityReport(val level: Compatibility, val notes: List<String>)

fun ExperienceManifest.checkCompatibility(dev: DeviceCapabilities): CompatibilityReport {
    val notes = ArrayList<String>()
    if (dev.sdk < minSdk) {
        return CompatibilityReport(Compatibility.INCOMPATIBLE, listOf("Requer Android SDK $minSdk ou superior."))
    }
    val missingRequired = requires.filter { it !in dev.available }
    if (missingRequired.isNotEmpty()) {
        missingRequired.forEach { notes += "Falta: ${it.label}." }
        return CompatibilityReport(Compatibility.INCOMPATIBLE, notes)
    }
    val missingOptional = optional.filter { it !in dev.available }
    missingOptional.forEach { notes += "Sem ${it.label}: funciona com recursos reduzidos." }
    return CompatibilityReport(if (missingOptional.isEmpty()) Compatibility.OK else Compatibility.PARTIAL, notes)
}

object ManifestValidator {
    private val idRegex = Regex("^[a-z0-9][a-z0-9-]{2,39}$")
    private val versionRegex = Regex("^\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}$")

    fun validate(m: ExperienceManifest): List<String> {
        val errors = ArrayList<String>()
        if (!idRegex.matches(m.id)) errors += "id inválido: use 3–40 caracteres [a-z0-9-]"
        if (m.name.isBlank() || m.name.length > 60) errors += "nome vazio ou longo demais"
        if (m.description.length > 400) errors += "descrição longa demais"
        if (!versionRegex.matches(m.version)) errors += "versão deve ser MAJOR.MINOR.PATCH"
        if (m.minSdk < 1) errors += "minSdk inválido"
        if (m.requires.intersect(m.optional).isNotEmpty()) errors += "capacidade não pode ser obrigatória e opcional"
        return errors
    }
}

/** Biblioteca local simples (Fase 10 evoluirá isto). Só experiências embutidas no app. */
object LocalExperienceRegistry {
    const val DEMO_WINDOW_ID = "demo-window"

    val all: List<ExperienceManifest> = listOf(
        ExperienceManifest(
            id = DEMO_WINDOW_ID,
            name = "Janela de demonstração",
            description = "Espaço com uma janela virtual que pode ser movida, redimensionada, minimizada e fechada, " +
                "com botão, chave e lista rolável para testar a interação.",
            version = "0.1.0",
            minSdk = 26,
            requires = setOf(Capability.TOUCH),
            optional = setOf(Capability.CAMERA, Capability.HAND_TRACKING),
            installState = InstallState.BUILT_IN,
            instructions = "Com mãos: aproxime polegar e indicador (pinça) sobre um elemento para selecionar; " +
                "mantenha a pinça e mova para arrastar. Sem mãos: use o toque na tela.",
        ),
    )

    fun find(id: String): ExperienceManifest? = all.firstOrNull { it.id == id }
}
